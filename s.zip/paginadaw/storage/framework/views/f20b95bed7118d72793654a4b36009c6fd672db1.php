<?php $__env->startSection('content'); ?>

	
		<div class="columnaLateral">
			<img class="columnaIzqFoto" src="img/wallpaper1.jpg">
			<img class="columnaIzqFoto" src="img/gif1.gif">
			<img class="columnaIzqFoto" src="img/gif3.gif">
		</div>


	<div id="columnaCentro">
		<div class="midColumnElement">
			<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
			  <ol class="carousel-indicators">
			    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
			    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
			    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
			    <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
			    <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
			  </ol>
			  <div class="carousel-inner">
			    <div class="carousel-item active" data-interval="4000">
			      <img src="img/gato1.jpg" class="d-block w-100" alt="...">
			    </div>
			    <div class="carousel-item" data-interval="4000">
			      <img src="img/gato2.jpg" class="d-block w-100" alt="...">
			    </div>
			    <div class="carousel-item" data-interval="4000">
			      <img src="img/gato3.jpg" class="d-block w-100" alt="...">
			    </div>
			    <div class="carousel-item" data-interval="4000">
			      <img src="img/gato4.jpg" class="d-block w-100" alt="...">
			    </div>
			    <div class="carousel-item" data-interval="4000">
			      <img src="img/gato5.jpg" class="d-block w-100" alt="...">
			    </div>
			  </div>
			  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
			    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
			    <span class="sr-only">Previous</span>
			  </a>
			  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
			    <span class="carousel-control-next-icon" aria-hidden="true"></span>
			    <span class="sr-only">Next</span>
			  </a>
			</div>
		</div>

		<hr>

		<div class="textoCentroHolder">
			<p id="textoGatos">El gato doméstico (Felis silvestris catus), llamado popularmente gato, y de forma coloquial minino, michino, michi, micho, mizo, miz, morroño o morrongo, entre otros nombres, es un mamífero carnívoro de la familia Felidae. Es una subespecie domesticada por la convivencia con el ser humano.
			<br><br>

			El nombre actual en muchas lenguas proviene del latín vulgar catus. Paradójicamente, catus aludía a los gatos salvajes, mientras que los gatos domésticos, en latín, eran llamados felis. <br><br>

			Como resultado de mutaciones genéticas, cruzamiento y selección artificial, hay numerosas razas. Algunas, como la raza Sphynx o la Peterbald están desprovistas de pelo; otras carecen de cola, como los gatos de la raza Manx, y algunas tienen coloraciones atípicas, como los llamados gatos azules. <br><br>

			El gato se comunica a través de vocalizaciones. Las más populares son su característico maullido y el ronroneo, pero puede aullar, gemir, gruñir y bufar. Además, adopta poses o expresiones que informan, a sus congéneres, sus enemigos o sus cuidadores, de su ánimo o sus intenciones. <br><br>

			Junto con el perro, es el animal doméstico más popular, como mascota, como ayuda en la lucha contra roedores o ambas cosas.</p>
		</div>
		<hr>
		<div class="midColumnElement">
			<img class="d-block w-100" src="img/gato6.jpg">

		</div>

	</div>



	<div class="columnaLateral">
		<img class="columnaDerFoto" src="img/wallpaper2.jpg">
		<img class="columnaDerFoto" src="img/gif2.gif">
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Programas\xampp\htdocs\paginadaw\resources\views/welcome.blade.php ENDPATH**/ ?>