@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
    		
	        <form class="post-create-form" action="{{ route('reply.store') }}" method="post">
	        	<script>tinymce.init({entity_encoding: 'raw', forced_root_block : "", selector:'#post-editor'});</script>
	        	@csrf
	    
	        	<div class="post-editor">
	        		<textarea id="post-editor" name="content" class="create-editor"></textarea>
	        	</div>
	        	<div class="submit-btn-section">
	        		<button type="submit">Submit</button>
	        		<input type="hidden" name="reply_author" value="{{ Auth::user()->id }}">
	        		<input type="hidden" name="post_id" value="{{ $post }}">


	        	</div>
	        </form>
        
    </div>
</div>




@endsection