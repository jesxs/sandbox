@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="post-holder">
            <div class="post-user-section">
                <div class="user-profile-pic-border" id="{{$post->author}}"></div>
                <img class="user-profile-pic-holder" src="/uploads/avatars/{{$author->avatar}}">
                <div class="username">{{$author->username}}</div>
            </div>
            <div class="post-content-section">
                <div class="post-title"><span>{{ $post->post_title }}</span></div>
                <div class="post-content"><span>{{ $post->content }}</span></div>
            </div>
            <div class="post-signature-section">
                
            </div>
            <div class="post-actions-section">
                <div class="post-reply"></div>
                <div class="post-quote"></div>
                <div class="post-report"></div>
            </div>
        </div>
        
    </div>
</div>
@endsection
