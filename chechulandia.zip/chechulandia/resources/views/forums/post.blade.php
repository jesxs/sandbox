@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="post-holder">
            <div class="post-user-section">
                <div class="user-profile-pic-border"></div>
                <div class="user-profile-pic-holder"></div>
            </div>
            <div class="post-content-section">
                <div class="post-title"><span>{{ $post->post_title }}</span></div>
                <div class="post-content"><span>{{ $post->content }}</span></div>
            </div>
            <div class="post-bottom-section">
                
            </div>

        </div>
    </div>
</div>
@endsection
