@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="post-holder">
            <div class="post-user-section">
                <div class="user-profile-pic-border" id="{{$post->author}}"></div>
                <img class="user-profile-pic-holder" src="/uploads/avatars/{{$author->avatar}}">
                <div class="username">{{$author->username}}</div>
            </div>
            <div class="post-content-section">
                <div class="post-title"><span>{{ $post->post_title }}</span></div>
                <div class="post-content"><span>{{ $post->content }}</span></div>
            </div>
            <div class="post-signature-section">
                
            </div>
            <div class="post-actions-section">
                <div class="post-reply"><button id="replyText" value="{{$post->id}}">Responder</button></div>
                <div class="post-quote"><button id="quoteText">Citar</button></div>
                <div class="post-report"></div>
            </div>
        </div>
        <div class="comment-section">
            @foreach ($reply as $reply)
                <div class="reply">
                    <div class="userinfo-section">
                        <img class="image-holder" src="/uploads/avatars/{{$author->find($reply->reply_author)->avatar}}">
                        <div class="reply-author-name">{{$author->find($reply->reply_author)->username}}</div>
                    </div>
                    <div class="content-section">
                        <span class="reply-content">{{$reply->content}}</span>
                    </div>
                    <div class="signature-section">
                        
                    </div>
                </div>
            @endforeach




        </div>
        
    </div>
</div>
@endsection
