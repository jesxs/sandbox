@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
    		
	        <form class="post-create-form" action="{{ route('posts.store') }}" method="post">
	        	<script>tinymce.init({entity_encoding: 'raw', forced_root_block : "", selector:'#post-editor'});</script>
	        	@csrf
	        	<div class="title-section">
	        		<label for="title-input">Title</label><br>
	        		<input class="title-input-post" type="text" name="post_title">
	        	</div>
	        	<div class="post-editor">
	        		<textarea id="post-editor" name="content" class="create-editor"></textarea>
	        	</div>
	        	<div class="submit-btn-section">
	        		<button type="submit">Submit</button>
	        		<input type="hidden" name="author" value="{{ Auth::user()->id }}">
	        	</div>
	        </form>
        
    </div>
</div>




@endsection