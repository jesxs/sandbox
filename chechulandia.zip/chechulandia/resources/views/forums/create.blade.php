@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="post-create-form">
        	<div class="title-section">
        		
        	</div>
        	<div class="post-editor">
        		
        	</div>
        	<div class="submit-btn-section">
        		<button></button>
        	</div>
        </div>
    </div>
</div>


@endsection