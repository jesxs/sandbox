@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <table class="forums-table">
        	<thead>
        		<th style="text-align: left;width: 3%;">Hora</th>
        		<th style="width: 32%;">Título</th>
        		<th style="width: 25%;">Tema</th>
        		<th style="width: 20%;">Autor</th>
        		<th style="width: 20%">Resp.</th>
        	</thead>
        	<tbody>
        		
        	</tbody>
        </table>
        <div class="forum-sidebar">
            <div class="forum-sidebar-item">
                <a href="/create"><button class="custom-btn">Create post</button></a>
            </div>
        </div>
    </div>
</div>
@endsection
