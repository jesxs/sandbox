@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <table class="forums-table">
        	<thead>
        		<th>Hora</th>
        		<th>Título</th>
        		<th>Tema</th>
        		<th>Autor</th>
        		<th>Resp.</th>
        	</thead>
        	<tbody class="">
                @foreach ($post as $post)
                <tr class="post" id="{{$post->id}}">
                    <td>{{$post->created_at}}</td>
                    <td>{{$post->post_title}}</td>
                    <td>{{$post->theme}}</td>
                    <td>{{$user->find($post->author)->username}}</td>
                    <td>{{0}}</td>
                </tr>
                @endforeach
        		
        	</tbody>
        </table>
        <div class="forum-sidebar">
            <div class="forum-sidebar-item">
                <a href="/create"><button class="custom-btn">Create post</button></a>
            </div>
        </div>
    </div>
</div>
@endsection
