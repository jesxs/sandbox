@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <table class="forums-table">
        	<thead>
        		<th style="text-align: left;width: 3%;">Hora</th>
        		<th style="width: 32%;">Título</th>
        		<th style="width: 25%;">Tema</th>
        		<th style="width: 20%;">Autor</th>
        		<th style="width: 20%">Resp.</th>
        	</thead>
        	<tbody>
                @foreach ($post as $post)
                <tr>
                    <td>{{$post->created_at}}</td>
                    <td>{{$post->post_title}}</td>
                    <td>{{$post->theme}}</td>
                    <td>{{$post->author}}</td>
                    <td>{{0}}</td>
                </tr>
                @endforeach
        		
        	</tbody>
        </table>
        <div class="forum-sidebar">
            <div class="forum-sidebar-item">
                <a href="/create"><button class="custom-btn">Create post</button></a>
            </div>
        </div>
    </div>
</div>
@endsection
