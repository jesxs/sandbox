@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div>   
            <div class="coming-text">COMING SOON CHAVALES...</div>
        </div>
    </div>
</div>
@endsection
