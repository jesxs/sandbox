@extends('layouts.app')

@section('content')

    <div class="parent">

        <div class="login-form-block-border"></div>

        <div class="login-form-block"></div>
        <div class="content-login-block">
            <form action="{{ route('login') }}" method="POST">
                <label class="form-label" for="username">Username</label><br>
                <input class="form-input" type="text" name="username"><br><br>
                <label class="form-label" for="password">Password</label><br>
                <input class="form-input" type="text" name="password"><br><br>
                    
               
            </form>
        </div>

    </div>


@endsection
