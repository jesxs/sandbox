@extends('layouts.app')

@section('content')

    @if(count($errors) > 0)
        <div class="alert alert-danger">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="parent">

        <div class="login-form-block-border"></div>

        <div class="login-form-block"></div>
        <div class="content-login-block">
            <form action="{{ route('login') }}" method="POST">
                {{ csrf_field() }}
                <label class="form-label" for="name">Username</label><br>
                <input class="form-input" type="text" name="identity"><br><br>
                
                <label class="form-label" for="password">Password</label><br>
                <input class="form-input" type="password" name="password"><br><br>

                <input type="submit" name="login" class="submit-form-btn">
               
            </form>
        </div>

    </div>


@endsection
