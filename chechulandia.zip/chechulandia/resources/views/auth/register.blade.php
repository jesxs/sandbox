@extends('layouts.app')

@section('content')
    @if(count($errors) > 0)
        <div class="alert alert-danger">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <div class="parent">

        <div class="login-form-block-border" style="height: 500px;"></div>

        <div class="login-form-block" style="height: 500px;"></div>
        <div class="content-login-block">
            <form action="{{ route('register') }}" method="POST">
                {{ csrf_field() }}
                <label class="form-label" for="username">Username</label><br>
                <input class="form-input" type="text" name="username"><br><br>

                <label class="form-label" for="email">Email</label><br>
                <input class="form-input" type="email" name="email"><br><br>
                
                <label class="form-label" for="password">Password</label><br>
                <input class="form-input" type="password" name="password"><br><br>

                <label class="form-label" for="passwordRepeat">Repeat password</label><br>
                <input class="form-input" type="password" name="password_confirmation"><br><br>

                <input type="submit" name="login" class="submit-form-btn">
               
            </form>
        </div>

    </div>

@endsection
