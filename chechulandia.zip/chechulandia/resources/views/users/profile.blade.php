@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="profile-panel">
        	<div class="profile-pic-section">
        		<div class="profile-pic-border"></div>
        		    <img src="/uploads/avatars/{{ $user->avatar }}" class="profile-pic">
        		<div class="profile-pic-holder"></div>
        	</div>
        	<div class="user-info-section">
        		<div class="profile-info-row">
	        		<div class="info-item">Name:</div>
	        		<div class="username">{{ $user->username }}</div>
	        	</div>
	        	<div class="profile-info-row">
	        		<div class="info-item">Since:</div>
	        		<div class="username">ayer</div>
	        	</div>
	        	<div class="profile-info-row">
	        		<div class="info-item">Posts:</div>
	        		<div class="username">{{ $posts->where('author',$user->id)->count() }}</div>
	        	</div>
	        	<div class="profile-info-row">
	        		<div class="info-item">Rep:</div>
	        		<div class="username">13.798</div>
	        	</div>
	        	<div class="profile-info-row">
	        		<div class="info-item">Poles:</div>
	        		<div class="username">999.999</div>
	        	</div>
        	</div>
        	<div class="signature-section">
        	
        		<div class="signature-content">
        			 ------------------------------------------------<br>
        			 comeme los webos
        		</div>
        	</div>

        </div>
    @if ($user->id == Auth::user()->id)
        <div class="own-profile-menu">
        	<a href="/edit-profile"><button id="edit-profile" class="edit-own-profile">Edit profile</button></a>
        </div>
    @endif
    </div>
</div>

@endsection