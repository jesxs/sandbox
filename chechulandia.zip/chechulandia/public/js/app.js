$(document).ready(function(){
	$(".post").click(function(){
	    window.location.replace('/post/'+($(this).attr("id")));
	        
	});
	$(".user-profile-pic-border").click(function(){
	    window.location.replace('/profile/'+($(this).attr("id")));
	        
	});
	$("#replyText").click(function(){
	    window.location.replace('/post/'+($(this).attr("value")+'/reply'));
	        
	});


});