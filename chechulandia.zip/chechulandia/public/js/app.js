$(document).ready(function(){
	$(".post").click(function(){
	    window.location.replace('/post/'+($(this).attr("id")));
	        
	});
});