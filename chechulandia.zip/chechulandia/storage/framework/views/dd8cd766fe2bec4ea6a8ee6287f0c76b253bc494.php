<?php $__env->startSection('content'); ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="parent">

        <div class="login-form-block-border"></div>

        <div class="login-form-block"></div>
        <div class="content-login-block">
            <form action="<?php echo e(route('login')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <label class="form-label" for="name">Username</label><br>
                <input class="form-input" type="text" name="identity"><br><br>
                
                <label class="form-label" for="password">Password</label><br>
                <input class="form-input" type="password" name="password"><br><br>

                <input type="submit" name="login" class="submit-form-btn">
               
            </form>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\chechulandia\resources\views/auth/login.blade.php ENDPATH**/ ?>