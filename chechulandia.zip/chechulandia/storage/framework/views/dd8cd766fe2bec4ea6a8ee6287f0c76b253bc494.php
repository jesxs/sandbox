<?php $__env->startSection('content'); ?>

    <div class="parent">

        <div class="login-form-block-border"></div>

        <div class="login-form-block"></div>
        <div class="content-login-block">
            <form action="<?php echo e(route('login')); ?>" method="POST">
                <label class="form-label" for="username">Username</label><br>
                <input class="form-input" type="text" name="username"><br><br>
                <label class="form-label" for="password">Password</label><br>
                <input class="form-input" type="text" name="password"><br><br>
                    
               
            </form>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\chechulandia\resources\views/auth/login.blade.php ENDPATH**/ ?>