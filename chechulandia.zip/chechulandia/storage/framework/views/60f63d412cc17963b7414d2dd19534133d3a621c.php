<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <table class="forums-table">
        	<thead>
        		<th>Hora</th>
        		<th>Título</th>
        		<th>Tema</th>
        		<th>Autor</th>
        		<th>Resp.</th>
        	</thead>
        	<tbody class="">
                <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="post" id="<?php echo e($post->id); ?>">
                    <td><?php echo e($post->created_at); ?></td>
                    <td><?php echo e($post->post_title); ?></td>
                    <td><?php echo e($post->theme); ?></td>
                    <td><?php echo e($user->find($post->author)->username); ?></td>
                    <td><?php echo e($replies->where('post_id',$post->id)->count()); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		
        	</tbody>
        </table>
        <div class="forum-sidebar">
            <div class="forum-sidebar-item">
                <a href="/create"><button class="custom-btn">Create post</button></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\chechulandia\resources\views/forums/index.blade.php ENDPATH**/ ?>