<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <table class="forums-table">
        	<thead>
        		<th style="text-align: left;width: 3%;">Hora</th>
        		<th style="width: 32%;">Título</th>
        		<th style="width: 25%;">Tema</th>
        		<th style="width: 20%;">Autor</th>
        		<th style="width: 20%">Resp.</th>
        	</thead>
        	<tbody>
        		
        	</tbody>
        </table>
        <div class="forum-sidebar">
            <div class="forum-sidebar-item">
                <a href="/create"><button class="custom-btn">Create post</button></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\chechulandia\resources\views/forums/index.blade.php ENDPATH**/ ?>