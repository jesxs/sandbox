<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="post-holder">
            <div class="post-user-section">
                <div class="user-profile-pic-border" id="<?php echo e($post->author); ?>"></div>
                <img class="user-profile-pic-holder" src="/uploads/avatars/<?php echo e($author->avatar); ?>">
                <div class="username"><?php echo e($author->username); ?></div>
            </div>
            <div class="post-content-section">
                <div class="post-title"><span><?php echo e($post->post_title); ?></span></div>
                <div class="post-content"><span><?php echo e($post->content); ?></span></div>
            </div>
            <div class="post-signature-section">
                
            </div>
            <div class="post-actions-section">
                <div class="post-reply"></div>
                <div class="post-quote"></div>
                <div class="post-report"></div>
            </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\chechulandia\resources\views/forums/post.blade.php ENDPATH**/ ?>