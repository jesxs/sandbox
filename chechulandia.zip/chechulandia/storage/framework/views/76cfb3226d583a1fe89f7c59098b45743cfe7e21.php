<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="post-holder">
            <div class="post-user-section">
                <div class="user-profile-pic-border" id="<?php echo e($post->author); ?>"></div>
                <img class="user-profile-pic-holder" src="/uploads/avatars/<?php echo e($author->avatar); ?>">
                <div class="username"><?php echo e($author->username); ?></div>
            </div>
            <div class="post-content-section">
                <div class="post-title"><span><?php echo e($post->post_title); ?></span></div>
                <div class="post-content"><span><?php echo e($post->content); ?></span></div>
            </div>
            <div class="post-signature-section">
                
            </div>
            <div class="post-actions-section">
                <div class="post-reply"><button id="replyText" value="<?php echo e($post->id); ?>">Responder</button></div>
                <div class="post-quote"><button id="quoteText">Citar</button></div>
                <div class="post-report"></div>
            </div>
        </div>
        <div class="comment-section">
            <?php $__currentLoopData = $reply; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="reply">
                    <div class="userinfo-section">
                        <img class="image-holder" src="/uploads/avatars/<?php echo e($author->find($reply->reply_author)->avatar); ?>">
                        <div class="reply-author-name"><?php echo e($author->find($reply->reply_author)->username); ?></div>
                    </div>
                    <div class="content-section">
                        <span class="reply-content"><?php echo e($reply->content); ?></span>
                    </div>
                    <div class="signature-section">
                        
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\chechulandia\resources\views/forums/post.blade.php ENDPATH**/ ?>