<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
    		
	        <form class="post-create-form" action="<?php echo e(route('posts.store')); ?>" method="post">
	        	<script>tinymce.init({entity_encoding: 'raw', forced_root_block : "", selector:'#post-editor'});</script>
	        	<?php echo csrf_field(); ?>
	        	<div class="title-section">
	        		<label for="title-input">Title</label><br>
	        		<input class="title-input-post" type="text" name="post_title">
	        	</div>
	        	<div class="post-editor">
	        		<textarea id="post-editor" name="content" class="create-editor"></textarea>
	        	</div>
	        	<div class="submit-btn-section">
	        		<button type="submit">Submit</button>
	        		<input type="hidden" name="author" value="<?php echo e(Auth::user()->id); ?>">
	        	</div>
	        </form>
        
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\chechulandia\resources\views/forums/create.blade.php ENDPATH**/ ?>