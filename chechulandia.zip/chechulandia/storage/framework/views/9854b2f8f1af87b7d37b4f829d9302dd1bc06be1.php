<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="post-create-form">
        	<div class="title-section">
        		
        	</div>
        	<div class="post-editor">
        		
        	</div>
        	<div class="submit-btn-section">
        		<button></button>
        	</div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\chechulandia\resources\views/forums/create.blade.php ENDPATH**/ ?>