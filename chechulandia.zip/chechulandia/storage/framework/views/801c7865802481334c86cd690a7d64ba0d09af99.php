<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="profile-panel">
        	<div class="profile-pic-section">
        		<img class="edit-profile-pic" src="https://i.ibb.co/7ySCZPC/pencil-edit-button.png" onclick="document.getElementById('submitFile').click();"></img>
        		<div class="profile-pic-border"></div>
            		<form enctype="multipart/form-data" action="/profile/update" method="post">
                        <input type="file" id="submitFile" class="edit-icon-file" name="avatar">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <button class="save-changes-button" type="submit">Save changes</button>
                    </form>
        		    <img src="/uploads/avatars/<?php echo e(Auth::user()->avatar); ?>" class="profile-pic">
        		<div class="profile-pic-holder"></div>
        	</div>
        	<div class="user-info-section">
        		<div class="profile-info-row">
	        		<div class="info-item">Name:</div>
	        		<div class="username"><?php echo e(Auth::user()->username); ?></div>
	        	</div>
	        	<div class="profile-info-row">
	        		<div class="info-item">Since:</div>
	        		<div class="username">ayer</div>
	        	</div>
	        	<div class="profile-info-row">
	        		<div class="info-item">Posts:</div>
	        		<div class="username"><?php echo e($posts->where('author',Auth::user()->id)->count()); ?></div>
	        	</div>
	        	<div class="profile-info-row">
	        		<div class="info-item">Rep:</div>
	        		<div class="username">13.798</div>
	        	</div>
	        	<div class="profile-info-row">
	        		<div class="info-item">Poles:</div>
	        		<div class="username">999.999</div>
	        	</div>
        	</div>
        	<div class="signature-section">
        		
        		<img class="edit-profile-pic" src="https://i.ibb.co/7ySCZPC/pencil-edit-button.png"></img>
        		<div class="signature-content">
        			 ------------------------------------------------<br>
        			 comeme los webos
        		</div>
        	</div>

        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\chechulandia\resources\views/users/profileEdit.blade.php ENDPATH**/ ?>