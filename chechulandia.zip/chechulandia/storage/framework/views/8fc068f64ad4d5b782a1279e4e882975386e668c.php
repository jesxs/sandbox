<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    

</head>
<body>
    <!--Navbar-->
            <nav class="navbar navbar-expand-md navbar-dark bg-dark" style="z-index: 3">
            <div class="navbar-collapse collapse w-100 order-1 order-md-0 dual-collapse2">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">Coming soon</a>
                    </li>
                  
                </ul>
            </div>
            <div class="mx-auto order-0">
                <a class="navbar-brand mx-auto" href="/">CHECHULANDIA</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".dual-collapse2">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
            <div class="navbar-collapse collapse w-100 order-3 dual-collapse2">
                <ul class="navbar-nav ml-auto">
                    <?php if(Auth::check()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('frm-logout').submit();">
                                Logout
                            </a>    
                            <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </li>
                    <?php else: ?>

                        <li class="nav-item">
                            <a class="nav-link" href="/login">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="register">Register</a>
                        </li>

                    <?php endif; ?>
                </ul>
            </div>
        </nav>
        <!--Navbar-->
        <!--Sidebar-->
    <?php if(Auth::check()): ?>
        <div class="sidenav">
            <div class="profile-section">
                <img class="profile-pic" src="https://media.giphy.com/media/hv4TC2Ide8rDoXy0iK/giphy.gif">
                <div class="profile-pic-border"></div>
                <div class="profile-pic-background"></div>
                <label class="username-text" for="username"><?php echo e(Auth::user()->username); ?></label>
            </div>
            <div class="sidebar-section">
                
            </div>


        </div>
    <?php endif; ?>

        <div class="background-image"></div>

        <br>
        
            <div style="z-index: 9999">
                <main class="py-4">
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            </div>
   
    </div>
</body>
</html>
<?php /**PATH D:\Programas\xampp\htdocs\chechulandia\resources\views/layouts/app.blade.php ENDPATH**/ ?>