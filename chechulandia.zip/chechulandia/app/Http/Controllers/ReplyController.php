<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Auth;
use App\User;
use App\Post;
use App\Comment;
use Image;

class ReplyController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function createReply($post){
        
        return view('forums.reply',[
            'post' => $post,
        ]);
    }
    public function store(Request $request)
    {
        $request['reply_author'] = Auth::user()->id;
        $validatedData = $request->validate([
            'content' => 'required',
            'post_id' => 'required',
            'reply_author' => 'required'
    
        ]);

        $comment = Comment::create($validatedData);

        return redirect('/post/'.$request['post_id']);
    }
    
    
}
