<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Auth;
use App\User;
use App\Post;
use Image;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index($id)
    {
        $user = User::find($id);

        return view('users.profile',[
            'user' => $user,
            'posts' => Post::all(),
        ]);
    }
    public function editProfile(){
        $user = Auth::user();
        return view('users.profileEdit',[
            'user' => Auth::user(),
            'posts' => Post::all(),
        ]);
    }

    public function update(Request $request){
        //handle user upload of avatar

        if(empty($request)){
            return view('users.profile');
        };


        if($request->hasFile('avatar')){
            $avatar = $request->file('avatar');
            $filename = time() . '.' . $avatar->getClientOriginalExtension();

            Image::make($avatar)->resize(300,300)->save( public_path('/uploads/avatars/'.$filename) );

            $user = Auth::user();
            $user->avatar = $filename;
            $user->save();

            return view('users.profile',[
                'user' => Auth::user(),
            ]);
        }
    }
    
    
}
