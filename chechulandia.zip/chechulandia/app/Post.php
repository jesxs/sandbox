<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $fillable = [
    	'post_title','theme','author','content'
    ];
     public function user()
    {
        return $this->hasOne('App\User');
    }
}
