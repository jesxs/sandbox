<?php

use Illuminate\Database\Seeder;

class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         DB::table('users')->insert([
            'name' => 'paul',
            'role' => 1,
            'password' => '$2y$10$fFBZJsBUQu27exes7Tmu2OGlKl0hQcrskzyOhZ40Y6BYWZ9wo.pj6',
        ]);
    }
}
