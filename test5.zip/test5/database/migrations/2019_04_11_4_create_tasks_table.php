<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTasksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void 
     */
    public function up()
    {
        Schema::create('tasks', function (Blueprint $table) {
            $table->increments('task_id')->unsigned();
            $table->integer('proj_id')->nullable()->default($value=null)->foreign('proj_id')->references('proj_id')->on('projects')->onDelete('cascade');
            $table->string('task_title',40)->default($value=null);
            $table->string('task_desc',500)->nullable()->default($value=null);
            $table->integer('person_id')->default($value=null);
            $table->enum('status',['not-started','in-progress','completed','cancelled'])->nullable()->default($value='not-started');
            $table->enum('priority',['urgent','high','medium','low'])->nullable()->default($value='medium');
            $table->integer('created_by')->nullable()->default($value=null);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tasks');
    }
}
