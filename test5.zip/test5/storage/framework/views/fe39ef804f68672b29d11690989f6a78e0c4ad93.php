<?php $__env->startSection('content'); ?>


<div class="row"> 

	<div class="col-1"></div>
		<div class="col-2">
<?php if(Auth::user()->role == 'admin'): ?>
			<br>
			<a class="btn btn-success" href="/projects/create">Add Project</a>
<?php endif; ?>
		</div>

	<div class="col-5">
		<form method="GET" action="/projects/results">
			<?php echo $__env->make('projects.filter_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</form>
	</div>

<div class="col-3">
<?php if(session()->has('store')): ?>
		<div class="alert alert-success mt-2" role="alert">
			<strong>Project created</strong>
		</div>
	<?php elseif(session()->has('update')): ?>
		<div class="alert alert-success mt-2" role="alert">
			<strong>Project updated</strong>
		</div>
	<?php elseif(session()->has('delete')): ?>
		<div class="alert alert-success mt-2" role="alert">
			<strong>Project deleted</strong>
		</div>
	<?php elseif(session()->has('nofilter')): ?>
		<div class="alert alert-danger mt-2" role="alert">
			<strong>Please enter a filter parameter</strong>
		</div>
	<?php elseif(session()->has('noTask')): ?>
		<div class="alert alert-danger mt-2" role="alert">
			<strong>This project doesnt have any task.</strong>
		</div>
	<?php endif; ?>
	</div>
</div>
<br>
<div class="row">

<div class="col-1"></div>
<div class="col-10">
<table class="table table-bordered table-hover">
	<thead>
		<tr>
			<th width="100px">Project Id</th>
			<th>Title</th>
			<th>Description</th>
			<th width="135px">Client</th>
			<th width="115px">Created by</th>
			<th width="175px">Created on</th>
			<?php if(Auth::user()->role=='admin'): ?>
			<th width="110px">Admin</th>
			
			<?php elseif(Auth::user()->role =='user'): ?>
			<th></th>
			<?php endif; ?>
		</tr>
		  
	</thead>
	<tbody class=""> 
		<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($project->proj_id); ?></td>
			<td><?php echo e($project->proj_title); ?></td>
			<td><?php echo e($project->proj_desc); ?></td>
			<td><?php echo e($client->find($project->client_id)->client_name); ?></td>
			<td><?php echo e($project->user->name); ?></td>
			<td><?php echo e($project->created_at); ?></td>
			
			<td>
				<div class="dropdown">
  					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>   

					<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
  			<?php if(Auth::user()->role=='admin'): ?>								   					
 				
 	  			 	<a class="dropdown-item" href="<?php echo e(route('projects.edit',$project)); ?>">Edit</a>

 	  			 	<form method="POST" action="<?php echo e(route('projects.destroy',$project)); ?>" onsubmit="return confirm('Are you sure you want to delete this?')">
 	  			 		<?php echo method_field('DELETE'); ?>
 	  			 		<?php echo csrf_field(); ?>
 			  		<button class="dropdown-item" type="submit">Delete</button>
			<?php endif; ?>
					<a class="dropdown-item" href="<?php echo e(route('projects.tasks',$project)); ?>">Tasks</a>

  				  	</form>
				 </div>
			</div>
			</td>
			

		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
</div>
<div class="col-1"></div>


</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views/projects/index.blade.php ENDPATH**/ ?>