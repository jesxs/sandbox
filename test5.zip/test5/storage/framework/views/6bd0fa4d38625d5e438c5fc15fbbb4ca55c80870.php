<?php echo csrf_field(); ?>

		<div class="row">
			<div class="col">
				<div class="form-group">
					<label for="client">Client</label>
					<select class="form-control" name="client">
						<option value="null"></option>
						<?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($client->client_id); ?>"><?php echo e($client->client_name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			<div class="col">
				<div class="form-group">
					<label for="Created by">Created by</label>
					<select class="form-control" name="created_by">
						<option value="null"></option>
						<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($user->user_id); ?>"><?php echo e($user->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			<!--
			<div class="col">
				<div class="form-group">
					<label for="statusFilter">Status</label>
					<select class="form-control" name="status">
						<option selected="selected"></option>
						<option value="1">Not started</option>
						<option value="2">In progress</option>
						<option value="3">Completed</option>
						<option value="4">Cancelled</option>
						
					</select>
				</div>
			</div>
			<div class="col">
				<div class="form-group">
					<label for="priorityFilter">Priority</label>
					<select class="form-control" name="priority">
						<option selected="selected"></option>
						<option value="1">Urgent</option>
						<option value="2">High</option>
						<option value="3">Medium</option>
						<option value="4">Low</option>
						
					</select>
				</div>
			</div>
		-->
			
			<div class="col">
				<div class="form-group">
					<br>
					<button type="submit" class="btn btn-warning">Filter</button>
						
				</div>
			</div>
			

		</div>


<?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views/projects/filter_form.blade.php ENDPATH**/ ?>