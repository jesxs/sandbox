<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-1"></div>
	<div class="col-4">
		<div class="badge badge-primary text-wrap">
			<h2 class="">Add client</h2>
		</div>
	</div>
</div>

	<br><br>

	<form method="POST" action="<?php echo e(route('clients.store')); ?>">
		<?php echo $__env->make('clients.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</form>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views/clients/create.blade.php ENDPATH**/ ?>