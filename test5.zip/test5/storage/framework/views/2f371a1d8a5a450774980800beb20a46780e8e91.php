<?php echo csrf_field(); ?> 
 
<div class="row"> 
 	<div class="col-1"></div>
 		<div class="col-4">
 	<?php if($errors->any()): ?>
 			<div class="alert alert-danger mt-2" role="alert">
				<strong><?php echo e(implode('', $errors->all(':message'))); ?></strong>
			</div>
	<?php endif; ?>
		</div>
		<div class="col"></div>
</div>

 <div class="row">
 	<div class="col-1"></div>
 	<div class="col-3">
		<div class="form-group">
			<label for="projectTitle">Project title</label>
			<input type="text" class="form-control" name="proj_title" value="<?php echo e(old('proj_title',$project->proj_title)); ?>">
		</div>
		</div>
</div>
<div class="row">
	<div class="col-1"></div>
	<div class="col-3">
		<div class="form-group">
		<label for="projectDesc">Description</label>
		<input type="text" class="form-control" name="proj_desc" value="<?php echo e(old('proj_desc',$project->proj_desc)); ?>">
		</div>
	</div>
</div>
<div class="row">
	<div class="col-1"></div>
	<div class="col-2">
	<div class="form-group">
		<label for="clientId">Client</label>
		<select name="client_id" class="form-control">
	<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($client->client_id); ?>"><?php echo e($client->client_name); ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
	</div>
	</div>
</div>
<br>
<div class="row">
	<div class="col-1"></div>
	<div class="col-1">
		<div class="form-group">
			<button type="submit" class="btn btn-success">Submit</button>
		</div>
	</div>
 </div><?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views/projects/form.blade.php ENDPATH**/ ?>