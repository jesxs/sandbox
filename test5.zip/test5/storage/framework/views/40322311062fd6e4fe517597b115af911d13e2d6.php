<?php $__env->startSection('content'); ?>
	
	<form method="GET" action="/projects/filter/result">
	<?php echo $__env->make('projects.filter_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</form>
	<br><br>
	<div>
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>Project Id</th>
					<th>Title</th>
					<th>Description</th>
					<th>Client</th>
					<th>Created by</th>
					<th>Created on</th>
				</tr>
			</thead>
		</table>

	</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views//projects/filter.blade.php ENDPATH**/ ?>