<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-1"></div>
	<div class="col-2">
<?php if(Auth::user()->role == 'admin'): ?>
<br>
	<a class="btn btn-success" href="/clients/create">Add Client</a>
	<br><br><br>
<?php endif; ?>
	</div>
	<div class="col-2">

		<?php if(session()->has('store')): ?>
		<div class="alert alert-success mt-2" role="alert">
			<strong>Client created</strong>
		</div>
	<?php elseif(session()->has('update')): ?>
		<div class="alert alert-success mt-2" role="alert">
			<strong>Client updated</strong>
		</div>
	<?php elseif(session()->has('delete')): ?>
		<div class="alert alert-danger mt-2" role="alert">
			<strong>Client deleted</strong> 
		</div>
	<?php endif; ?>

	</div>
</div>
<div class="row">
	<div class="col-1"></div>
	<div class="col-4">
<table class="table table-bordered table-hover">
	<thead>
		<tr>
			<th width="90px">Client Id</th>
			<th width="140px">Client name</th>
			<?php if(Auth::user()->role=='admin'): ?>
			<th width="110px">Admin</th>
			<?php endif; ?>
		</tr>
		
	</thead>
	<tbody class="">
		<?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($client->client_id); ?></td>
			<td><?php echo e($client->client_name); ?></td>
			<?php if(Auth::user()->role=='admin'): ?>
			<td>
				<div class="dropdown">
  					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>   							   					
 				<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
 	  			 	<a class="dropdown-item" href="<?php echo e(route('clients.edit',$client)); ?>">Edit</a>

 	  			 	<form method="POST" action="<?php echo e(route('clients.destroy',$client)); ?>" onsubmit="return confirm('Are you sure you want to delete this?')">
 	  			 		<?php echo method_field('DELETE'); ?>
 	  			 		<?php echo csrf_field(); ?>
 			  		<button class="dropdown-item" type="submit">Delete</button> 
  				  	</form>
				 </div>
			</div>
			</td>
			<?php endif; ?>

		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
</div>
<div class="col.2"></div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views/clients/index.blade.php ENDPATH**/ ?>