<?php echo csrf_field(); ?> 

<div class="row">
	<div class="col-1"></div>
 		<div class="col-3">
 	<?php if($errors->any()): ?>
 			<div class="alert alert-danger mt-2" role="alert">
				<strong><?php echo e(implode('', $errors->all(':message'))); ?></strong>
			</div>
	<?php endif; ?>
		</div>
	<div class="col"></div>
</div>

<div class="row">
 	<div class="col-1"></div>
 		<div class="col-3">
			<div class="form-group">
				<label for="taskTitle">Task title</label>
				<input type="text" class="form-control" name="task_title" value="<?php echo e(old('task_title',$task->task_title)); ?>">
			</div>
		</div>
		<div class="col-2">
			<div class="form-group">
				<label for="Person">Person</label>
				<select name="person_id" class="form-control">
				<?php if(count($person) == 0): ?>			
					<option>There are no persons.</option>
				<?php else: ?>
				<?php $__currentLoopData = $person; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($person->user_id); ?>"><?php echo e($person->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
				</select>
			</div>
		</div>
</div>
<div class="row">
	<div class="col-1"></div>
		<div class="col-3">
			<div class="form-group">
				<label for="taskDesc">Description</label>
				<input type="text" class="form-control" name="task_desc" value="<?php echo e(old('task_desc',$task->task_desc)); ?>">
			</div>
		</div>
		<div class="col-2">
			<div class="form-group">
 				<label for="status" class="text-dark">Status</label>
				<select name="status" class="form-control" value="<?php echo e(old('status', $task->status)); ?>">
					<option value="1" selected="selected">Not started</option>
					<option value="2">In progress</option>
					<option value="3">Completed</option>
					<option value="4">Cancelled</option>
				</select>
 			</div>
		</div>
</div>
<div class="row">
	<div class="col-1"></div>
		<div class="col-2">
			<div class="form-group">
				<label for="proj_id">Project</label>
				<select name="proj_id" class="form-control">
					<?php if(count($project) == 0): ?>			
					<option>There are no projects.</option>
					<?php else: ?>
						<?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($project->proj_id); ?>"><?php echo e($project->proj_title); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
					
				</select>
			</div>
		</div>
		<div class="col-1"></div>
		<div class="col-2">
			<div class="form-group">
 				<label for="Priority" class="text-dark">Priority</label>
				<select name="priority" class="form-control" value="<?php echo e(old('priority', $task->priority)); ?>">
					<option value="1">Urgent</option>
					<option value="2">High</option>
					<option value="3" selected="selected">Medium</option>
					<option value="4">Low</option>
				</select>
 			</div>
		</div>
</div>
<br>
<div class="row">
	<div class="col-1"></div>
	<div class="col-2">
			<div class="form-group">
				<button type="submit" class="btn btn-success">Submit</button>
			</div>
	</div>
</div>

<?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views/tasks/form.blade.php ENDPATH**/ ?>