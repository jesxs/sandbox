<?php echo csrf_field(); ?>
<div class="col">
	<div class="form-group">
		<input type="text" class="form-control" name="note">
	</div>
</div>

<div class="col-10">
	<div class="form-group">
		<button class="btn btn-success" type="submit">Add note</button>
		<br><br>
	</div>
	<input type="hidden" name="task_id" value="<?php echo e($task->task_id); ?>">
</div>

<?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views/notes/form.blade.php ENDPATH**/ ?>