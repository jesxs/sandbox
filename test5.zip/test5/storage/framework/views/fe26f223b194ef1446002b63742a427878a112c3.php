 

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-4">
		<form method="POST" action="<?php echo e(route('users.update',$user)); ?>">
			<?php echo method_field('PUT'); ?>
			<?php echo $__env->make('users.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views/users/edit.blade.php ENDPATH**/ ?>