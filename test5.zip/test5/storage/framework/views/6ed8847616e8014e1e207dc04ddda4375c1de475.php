<?php $__env->startSection('content'); ?>

<div class="row"> 
	<div class="col">
<?php if(Auth::user()->role == 1): ?>
	<a class="btn btn-success" href="/people/create">Add User</a>
<?php endif; ?>
</div>
<div class="col"></div>
<div class="col">
<?php if(session()->has('store')): ?>
		<div class="alert alert-success mt-2" role="alert">
			<strong>User created</strong>
		</div>
	<?php elseif(session()->has('update')): ?>
		<div class="alert alert-success mt-2" role="alert">
			<strong>User updated</strong>
		</div>
	<?php elseif(session()->has('delete')): ?>
		<div class="alert alert-success mt-2" role="alert">
			<strong>User deleted</strong>
		</div>
	<?php endif; ?>
	</div>
	</div>
<br>
<table class="table table-bordered table-hover">
	<thead>
		<tr>
			<th>User Id</th>
			<th>Name</th>
			<th>Role</th>
			<?php if(Auth::user()->role==1): ?>
			<th>Admin</th>
			<?php endif; ?>
		</tr>
		
	</thead>
	<tbody class="">
		<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($user->id); ?></td>
			<td><?php echo e($user->name); ?></td>
			<td><?php echo e($user->role); ?></td>

			<?php if(Auth::user()->role==1): ?>
			<td>
				<div class="dropdown">
  					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>   							   					
 				<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
 	  			 	<a class="dropdown-item" href="<?php echo e(route('projects.edit',$project)); ?>">Edit</a>

 	  			 	<form method="POST" action="<?php echo e(route('projects.destroy',$project)); ?>" onsubmit="return confirm('Are you sure you want to delete this?')">
 	  			 		<?php echo method_field('DELETE'); ?>
 	  			 		<?php echo csrf_field(); ?>
 			  		<button class="dropdown-item" type="submit">Delete</button>
  				  	</form>
				 </div>
			</div>
			</td>
			<?php endif; ?>

		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views/people/index.blade.php ENDPATH**/ ?>