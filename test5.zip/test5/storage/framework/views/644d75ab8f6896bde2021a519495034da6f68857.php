<?php echo csrf_field(); ?>
		<div class="row">
			<div class="col">
				<div class="form-group">
					<label for="personFilter">Person</label>
					<select class="form-control" name="person">
						<option selected="selected" value="null"></option>
						<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($person->user_id); ?>"><?php echo e($person->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</select>
				</div>
			</div>
			<div class="col">
				<div class="form-group">
					<label for="statusFilter">Status</label>
					<select class="form-control" name="status">
						<option selected="selected" value="null"></option>
						<option value="not-started">Not started</option>
						<option value="in-progress">In progress</option>
						<option value="completed">Completed</option>
						<option value="cancelled">Cancelled</option>
						
					</select>
				</div>
			</div>
			<div class="col">
				<div class="form-group">
					<label for="priorityFilter">Priority</label>
					<select class="form-control" name="priority">
						<option selected="selected" value="null"></option>
						<option value="urgent">Urgent</option>
						<option value="high">High</option>
						<option value="medium">Medium</option>
						<option value="low">Low</option>
						
					</select>
				</div>
			</div>
		
			
			<div class="col">
				<div class="form-group">
					<br>
					<button type="submit" class="btn btn-warning">Filter</button>
				</div>
			</div>


</div>
<?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views/tasks/filter_form.blade.php ENDPATH**/ ?>