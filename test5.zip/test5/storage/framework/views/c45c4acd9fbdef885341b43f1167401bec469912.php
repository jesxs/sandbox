<?php echo csrf_field(); ?>
		<div class="row">
			<div class="col">
				<div class="form-group">
					<label for="statusFilter">Status</label>
					<select class="form-control" name="status">
						<option selected="selected" value="null"></option>
						<option value="1">Not started</option>
						<option value="2">In progress</option>
						<option value="3">Completed</option>
						<option value="4">Cancelled</option>
						
					</select>
				</div>
			</div>
			<div class="col">
				<div class="form-group">
					<label for="priorityFilter">Priority</label>
					<select class="form-control" name="priority">
						<option selected="selected" value="null"></option>
						<option value="1">Urgent</option>
						<option value="2">High</option>
						<option value="3">Medium</option>
						<option value="4">Low</option>
						
					</select>
				</div>
			</div>
		
			
			<div class="col">
				<div class="form-group">

					<button type="submit" class="btn btn-warning">Filter</button>
				</div>
			</div>


</div>
<?php /**PATH /var/www/html/test5/resources/views/tasks/filter_form.blade.php ENDPATH**/ ?>