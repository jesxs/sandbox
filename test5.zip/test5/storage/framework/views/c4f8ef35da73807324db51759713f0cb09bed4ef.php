 

<?php $__env->startSection('content'); ?>
	<form method="POST" action="<?php echo e(route('tasks.update',$task)); ?>">
		<?php echo method_field('PUT'); ?>
	<?php echo $__env->make('tasks.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</form>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views/tasks/edit.blade.php ENDPATH**/ ?>