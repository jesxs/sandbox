<?php $__env->startSection('content'); ?>
	<form method="GET" action="/tasks/results">
	<?php echo $__env->make('tasks.filter_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</form>

<table class="table table-bordered table-hover">
	<thead>
		<tr>
			<th>Task Id</th>
			<th>Project</th>
			<th>Task title</th>
			<th>Description</th>
			<th>Status</th>
			<th>Priority</th>
			<th>Created by</th>
			<th>Created on</th>
			<?php if(Auth::user()->role=='admin'): ?>
			<th>Admin</th>
			<?php endif; ?>
		</tr>
		
	</thead>
	<tbody class="">
		<?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($task->task_id); ?></td>
			<td><?php echo e($task->project->proj_title); ?></td>
			<td><?php echo e($task->task_title); ?></td>
			<td><?php echo e($task->task_desc); ?></td>
			<td><?php echo e($task->status); ?></td>
			<td><?php echo e($task->priority); ?></td>
			<td><?php echo e($task->user->name); ?></td>
			<td><?php echo e($task->created_at); ?></td>
			<?php if(Auth::user()->role=='admin'): ?>
			<td>
				<div class="dropdown">
  					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>   							   					
 				<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
 	  			 	<a class="dropdown-item" href="<?php echo e(route('tasks.edit',$task)); ?>">Edit</a>

 	  			 	<form method="POST" action="<?php echo e(route('tasks.destroy',$task)); ?>" onsubmit="return confirm('Are you sure you want to delete this?')">
 	  			 		<?php echo method_field('DELETE'); ?>
 	  			 		<?php echo csrf_field(); ?>
 			  		<button class="dropdown-item" type="submit">Delete</button>
  				  	</form>
				 </div>
			</div>
			</td>
			<?php endif; ?>

		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views/tasks/results.blade.php ENDPATH**/ ?>