<?php $__env->startSection('content'); ?>
<div class="row">


	<form method="POST" action="<?php echo e(route('notes.store')); ?>">
		<?php echo $__env->make('notes.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</form>
</div>
<div class="row">

<div class="col-8">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th width="185">#</th>
				<th width="400">Note</th>
				<th>Actions</th>
			</tr>
		</thead>	
		<tbody>
			<?php $__currentLoopData = $notes->where('task_id',$task->task_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td>Created by <?php echo e($note->user->name); ?></td>
				<td><?php echo e($note->note); ?></td>
				<td>
					<div class="dropdown">
  					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>   
					<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
						<a class="dropdown-item" href="<?php echo e(route('notes.destroy',$note)); ?>">Delete</a>
					</div>
				</div>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</tbody>

	</table>
</div>




</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programas\xampp\htdocs\test5\resources\views/notes/index.blade.php ENDPATH**/ ?>