

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-4">
		<div class="badge badge-primary text-wrap">
			<h2 class=""> Create an user </h2>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-4">
<br><br>

	<form method="POST" action="<?php echo e(route('users.store')); ?>">
		<?php echo $__env->make('users.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</form>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/test5/resources/views/users/create.blade.php ENDPATH**/ ?>