

<?php $__env->startSection('content'); ?>
<div class="row">	
	<div class="col-4">
	<div class="badge badge-primary text-wrap">
	<h2 class="">Create task</h2>
	</div>
	</div>
</div>
<div class="row">
	<div class="col-4">
<br><br>

	<form method="POST" action="<?php echo e(route('tasks.store')); ?>">
		<?php echo $__env->make('tasks.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/test5/resources/views/tasks/create.blade.php ENDPATH**/ ?>