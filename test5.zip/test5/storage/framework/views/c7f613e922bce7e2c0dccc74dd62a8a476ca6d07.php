

<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-2">
<?php if(Auth::user()->role == 'admin'): ?>
	<a class="btn btn-success" href="/clients/create">Add Client</a>
<?php endif; ?>
	</div>
	
 

 </div>
<br><br>
<table class="table table-bordered table-hover">
	<thead>
		<tr>
			<th>Client Id</th>
			<th>Client name</th>
			<?php if(Auth::user()->role=='admin'): ?>
			<th>Admin</th>
			<?php endif; ?>
		</tr>
		
	</thead>
	<tbody class="">
		<?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($client->client_id); ?></td>
			<td><?php echo e($client->client_name); ?></td>
			<?php if(Auth::user()->role=='admin'): ?>
			<td>
				<div class="dropdown">
  					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>   							   					
 				<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
 	  			 	<a class="dropdown-item" href="<?php echo e(route('clients.edit',$client)); ?>">Edit</a>

 	  			 	<form method="POST" action="<?php echo e(route('clients.destroy',$client)); ?>" onsubmit="return confirm('Are you sure you want to delete this?')">
 	  			 		<?php echo method_field('DELETE'); ?>
 	  			 		<?php echo csrf_field(); ?>
 			  		<button class="dropdown-item" type="submit">Delete</button> 
  				  	</form>
				 </div>
			</div>
			</td>
			<?php endif; ?>

		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/test5/resources/views/clients/index.blade.php ENDPATH**/ ?>