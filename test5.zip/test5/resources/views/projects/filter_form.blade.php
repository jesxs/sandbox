@csrf

		<div class="row">
			<div class="col">
				<div class="form-group">
					<label for="client">Client</label>
					<select class="form-control" name="client">
						<option value="null"></option>
						@foreach ($client as $client)
						<option value="{{$client->client_id}}">{{$client->client_name}}</option>
						@endforeach
					</select>
				</div>
			</div>
			<div class="col">
				<div class="form-group">
					<label for="Created by">Created by</label>
					<select class="form-control" name="created_by">
						<option value="null"></option>
						@foreach ($user as $user)
						<option value="{{$user->user_id}}">{{$user->name}}</option>
						@endforeach
					</select>
				</div>
			</div>
			<!--
			<div class="col">
				<div class="form-group">
					<label for="statusFilter">Status</label>
					<select class="form-control" name="status">
						<option selected="selected"></option>
						<option value="1">Not started</option>
						<option value="2">In progress</option>
						<option value="3">Completed</option>
						<option value="4">Cancelled</option>
						
					</select>
				</div>
			</div>
			<div class="col">
				<div class="form-group">
					<label for="priorityFilter">Priority</label>
					<select class="form-control" name="priority">
						<option selected="selected"></option>
						<option value="1">Urgent</option>
						<option value="2">High</option>
						<option value="3">Medium</option>
						<option value="4">Low</option>
						
					</select>
				</div>
			</div>
		-->
			
			<div class="col">
				<div class="form-group">
					<br>
					<button type="submit" class="btn btn-warning">Filter</button>
						
				</div>
			</div>
			

		</div>


