@csrf 
 
<div class="row"> 
 	<div class="col-1"></div>
 		<div class="col-4">
 	@if ($errors->any())
 			<div class="alert alert-danger mt-2" role="alert">
				<strong>{{ implode('', $errors->all(':message')) }}</strong>
			</div>
	@endif
		</div>
		<div class="col"></div>
</div>

 <div class="row">
 	<div class="col-1"></div>
 	<div class="col-3">
		<div class="form-group">
			<label for="projectTitle">Project title</label>
			<input type="text" class="form-control" name="proj_title" value="{{old('proj_title',$project->proj_title)}}">
		</div>
		</div>
</div>
<div class="row">
	<div class="col-1"></div>
	<div class="col-3">
		<div class="form-group">
		<label for="projectDesc">Description</label>
		<input type="text" class="form-control" name="proj_desc" value="{{old('proj_desc',$project->proj_desc)}}">
		</div>
	</div>
</div>
<div class="row">
	<div class="col-1"></div>
	<div class="col-2">
	<div class="form-group">
		<label for="clientId">Client</label>
		<select name="client_id" class="form-control">
	@foreach($clients as $client)
		<option value="{{$client->client_id}}">{{$client->client_name}}</option>
	@endforeach
		</select>
	</div>
	</div>
</div>
<br>
<div class="row">
	<div class="col-1"></div>
	<div class="col-1">
		<div class="form-group">
			<button type="submit" class="btn btn-success">Submit</button>
		</div>
	</div>
 </div>