@extends('layouts.app')

@section('content')


<div class="row"> 

	<div class="col-1"></div>
		<div class="col-2">
@if (Auth::user()->role == 'admin')
			<br>
			<a class="btn btn-success" href="/projects/create">Add Project</a>
@endif
		</div>

	<div class="col-5">
		<form method="GET" action="/projects/results">
			@include('projects.filter_form')
		</form>
	</div>

<div class="col-3">
@if(session()->has('store'))
		<div class="alert alert-success mt-2" role="alert">
			<strong>Project created</strong>
		</div>
	@elseif(session()->has('update'))
		<div class="alert alert-success mt-2" role="alert">
			<strong>Project updated</strong>
		</div>
	@elseif(session()->has('delete'))
		<div class="alert alert-success mt-2" role="alert">
			<strong>Project deleted</strong>
		</div>
	@elseif(session()->has('nofilter'))
		<div class="alert alert-danger mt-2" role="alert">
			<strong>Please enter a filter parameter</strong>
		</div>
	@elseif(session()->has('noTask'))
		<div class="alert alert-danger mt-2" role="alert">
			<strong>This project doesnt have any task.</strong>
		</div>
	@endif
	</div>
</div>
<br>
<div class="row">

<div class="col-1"></div>
<div class="col-10">
<table class="table table-bordered table-hover">
	<thead>
		<tr>
			<th width="100px">Project Id</th>
			<th>Title</th>
			<th>Description</th>
			<th width="135px">Client</th>
			<th width="115px">Created by</th>
			<th width="175px">Created on</th>
			@if (Auth::user()->role=='admin')
			<th width="110px">Admin</th>
			
			@elseif(Auth::user()->role =='user')
			<th></th>
			@endif
		</tr>
		  
	</thead>
	<tbody class=""> 
		@foreach ($projects as $project)
		<tr>
			<td>{{$project->proj_id}}</td>
			<td>{{$project->proj_title}}</td>
			<td>{{$project->proj_desc}}</td>
			<td>{{$client->find($project->client_id)->client_name}}</td>
			<td>{{$project->user->name}}</td>
			<td>{{$project->created_at}}</td>
			
			<td>
				<div class="dropdown">
  					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>   

					<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
  			@if (Auth::user()->role=='admin')								   					
 				
 	  			 	<a class="dropdown-item" href="{{route('projects.edit',$project)}}">Edit</a>

 	  			 	<form method="POST" action="{{route('projects.destroy',$project)}}" onsubmit="return confirm('Are you sure you want to delete this?')">
 	  			 		@method('DELETE')
 	  			 		@csrf
 			  		<button class="dropdown-item" type="submit">Delete</button>
			@endif
					<a class="dropdown-item" href="{{route('projects.tasks',$project)}}">Tasks</a>

  				  	</form>
				 </div>
			</div>
			</td>
			

		</tr>
		@endforeach
	</tbody>
</table>
</div>
<div class="col-1"></div>


</div>



@endsection