@extends('layouts.app')

@section('content')
<div class="row">
	<div class="col-1"></div>
	<div class="col-4">
		<div class="badge badge-primary text-wrap">
			<h2 class="">Create project</h2>
		</div>
	</div>
</div>

<br><br>

	<form method="POST" action="{{route('projects.store')}}">
		@include('projects.form')
	</form>



@endsection