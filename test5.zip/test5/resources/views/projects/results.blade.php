@extends('layouts.app')

@section('content')
	<form method="GET" action="/projects/results">
	@include('projects.filter_form')
	</form>

	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Project Id</th>
				<th>Title</th>
				<th>Description</th>
				<th>Client</th>
				<th>Created by</th>
				<th>Created on</th>
				@if(Auth::user()->role == 'admin')
				<th>Admin</th>
				@endif
				
			</tr>
		</thead>
		<tbody>
			@foreach ($project as $project)
			<tr>
				<td>{{$project->proj_id}}</td>
				<td>{{$project->proj_title}}</td>
				<td>{{$project->proj_desc}}</td>
				<td>{{$client->find($project->client_id)->client_name}}</td>
				<td>{{$project->user->name}}</td>
				<td>{{$project->created_at}}</td>
				@if(Auth::user()->role == 'admin')
				<td>
				<div class="dropdown">
  					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>   							   					
 				<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
 	  			 	<a class="dropdown-item" href="{{route('projects.edit',$project)}}">Edit</a>

 	  			 	<form method="POST" action="{{route('projects.destroy',$project)}}" onsubmit="return confirm('Are you sure you want to delete this?')">
 	  			 		@method('DELETE')
 	  			 		@csrf
 			  		<button class="dropdown-item" type="submit">Delete</button>
  				  	</form>
				 </div>
			</div>
			</td>
				@endif
			</tr>
			@endforeach
		</tbody>
	</table>



@endsection