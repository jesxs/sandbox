@extends('layouts.app')

@section('content')
<div class="row">
	<div class="col-4">
	<form method="POST" action="{{route('projects.update',$project)}}">
		@method('PUT')
	@include('projects.form')

	</form>
	</div>
</div>
@endsection 