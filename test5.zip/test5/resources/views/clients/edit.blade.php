 @extends('layouts.app')

@section('content')
<div class="row">
	<div class="col-4">
	<form method="POST" action="{{route('clients.update',$client)}}">
		@method('PUT')
	@include('clients.form')

	</form>
	</div>
</div>
@endsection 