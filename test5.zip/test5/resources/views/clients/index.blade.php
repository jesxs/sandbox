@extends('layouts.app')

@section('content')

<div class="row">
	<div class="col-1"></div>
	<div class="col-2">
@if (Auth::user()->role == 'admin')
<br>
	<a class="btn btn-success" href="/clients/create">Add Client</a>
	<br><br><br>
@endif
	</div>
	<div class="col-2">

		@if(session()->has('store'))
		<div class="alert alert-success mt-2" role="alert">
			<strong>Client created</strong>
		</div>
	@elseif(session()->has('update'))
		<div class="alert alert-success mt-2" role="alert">
			<strong>Client updated</strong>
		</div>
	@elseif(session()->has('delete'))
		<div class="alert alert-danger mt-2" role="alert">
			<strong>Client deleted</strong> 
		</div>
	@endif

	</div>
</div>
<div class="row">
	<div class="col-1"></div>
	<div class="col-4">
<table class="table table-bordered table-hover">
	<thead>
		<tr>
			<th width="90px">Client Id</th>
			<th width="140px">Client name</th>
			@if (Auth::user()->role=='admin')
			<th width="110px">Admin</th>
			@endif
		</tr>
		
	</thead>
	<tbody class="">
		@foreach ($client as $client)
		<tr>
			<td>{{$client->client_id}}</td>
			<td>{{$client->client_name}}</td>
			@if (Auth::user()->role=='admin')
			<td>
				<div class="dropdown">
  					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>   							   					
 				<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
 	  			 	<a class="dropdown-item" href="{{route('clients.edit',$client)}}">Edit</a>

 	  			 	<form method="POST" action="{{route('clients.destroy',$client)}}" onsubmit="return confirm('Are you sure you want to delete this?')">
 	  			 		@method('DELETE')
 	  			 		@csrf
 			  		<button class="dropdown-item" type="submit">Delete</button> 
  				  	</form>
				 </div>
			</div>
			</td>
			@endif

		</tr>
		@endforeach
	</tbody>
</table>
</div>
<div class="col.2"></div>
</div>





@endsection