@csrf

 <div class="row">
 	<div class="col-1"></div>
 		<div class="col-4">
 	@if ($errors->any())
 			<div class="alert alert-danger mt-2" role="alert">
				<strong>{{ implode('', $errors->all(':message')) }}</strong>
			</div>
		</div>
	@endif
	</div>
 </div>
<div class="row">
 	<div class="col-1"></div>
 	<div class="col-2">
		<div class="form-group">
			<label for="clientName">Client name</label>
			<input type="text" class="form-control" name="client_name" value="{{old('client_name',$client->client_name)}}">
		</div>
	</div>
</div>
<br>
<div class="row">
	<div class="col-1"></div>
	<div class="col-2">
		<div class="form-group">
			<button type="submit" class="btn btn-success">Submit</button>
		</div>
	</div>
</div>


