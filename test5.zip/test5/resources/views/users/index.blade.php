@extends('layouts.app')

@section('content')
<br>
<div class="row"> 
	<div class="col-1"></div>
	<div class="col-2">
@if (Auth::user()->role == 'admin')
	<a class="btn btn-success" href="/users/create">Add User</a>
@endif
	</div>
<div class="col-2">
@if(session()->has('store'))
		<div class="alert alert-success mt-2" role="alert">
			<strong>User created</strong>
		</div>
	@elseif(session()->has('update'))
		<div class="alert alert-success mt-2" role="alert">
			<strong>User updated</strong>
		</div>
	@elseif(session()->has('delete'))
		<div class="alert alert-success mt-2" role="alert">
			<strong>User deleted</strong>
		</div>
	@endif
	</div>
</div>
<br><br>
<div class="row">
	<div class="col-1"></div>
	<div class="col-4">
<table class="table table-bordered table-hover">
	<thead>
		<tr>
			<th>Id</th>
			<th>Name</th>
			<th>Role</th>
			@if (Auth::user()->role=='admin')
			<th>Admin</th>
			@endif
		</tr>
		
	</thead>
	<tbody class="">
		@foreach ($user as $user)
		<tr>
			<td>{{$user->user_id}}</td>
			<td>{{$user->name}}</td>
			<td>{{$user->role}}</td>

			@if (Auth::user()->role=='admin')
			<td>
				<div class="dropdown">
  					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>   							   					
 				<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
 	  			 	<a class="dropdown-item" href="{{route('users.edit',$user)}}">Edit</a>

 	  			 	<form method="POST" action="{{route('users.destroy',$user)}}" onsubmit="return confirm('Are you sure you want to delete this?')">
 	  			 		@method('DELETE')
 	  			 		@csrf
 			  		<button class="dropdown-item" type="submit">Delete</button>
  				  	</form>
				 </div>
			</div>
			</td>
			@endif

		</tr>
		@endforeach
	</tbody>
</table>
</div>
</div>

@endsection