@csrf 
 
 <div class="row"> 
 	@if ($errors->any())
 		<div class="alert alert-danger mt-2" role="alert">
			<strong>{{ implode('', $errors->all(':message')) }}</strong>
		</div>
	@endif
 </div>

	<div class="form-group">
		<label for="User name">User name</label>
		<input type="text" class="form-control" name="name" value="{{old('name',$user->name)}}">
	</div>
	<div class="form-group">
		<label for="password">Password</label>
		<input type="text" class="form-control" name="password" placeholder="password">
	</div>
	
	<div class="form-group">
		<label for="role">Role</label>
		<select name="role" value="{{old('role',$user->role)}}" class="form-control">
			<option value="null" selected=""></option>
			<option value="1">Admin</option>
			<option value="2">Regular user</option>
			
		</select>
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-success">Submit</button>
	</div>
 

