 @extends('layouts.app')

@section('content')
<div class="row">
	<div class="col-4">
		<form method="POST" action="{{route('users.update',$user)}}">
			@method('PUT')
			@include('users.form')
		</form>
	</div>
</div>
@endsection 