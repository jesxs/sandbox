@extends('layouts.app')

@section('content')
<div class="row">
	<div class="col-4">
		<div class="badge badge-primary text-wrap">
			<h2 class=""> Create an user </h2>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-4">
<br><br>

	<form method="POST" action="{{route('users.store')}}">
		@include('users.form')
	</form>

	</div>
</div>
@endsection