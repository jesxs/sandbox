@extends('layouts.app')

@section('content')
<div class="row">


	<form method="POST" action="{{route('notes.store')}}">
		@include('notes.form')
	</form>
</div>
<div class="row">

<div class="col-8">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th width="185">#</th>
				<th width="400">Note</th>
				<th>Actions</th>
			</tr>
		</thead>	
		<tbody>
			@foreach($notes->where('task_id',$task->task_id) as $note)
			<tr>
				<td>Created by {{$note->user->name}}</td>
				<td>{{$note->note}}</td>
				<td>
					<div class="dropdown">
  					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>   
					<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
						<a class="dropdown-item" href="{{route('notes.destroy',$note)}}">Delete</a>
					</div>
				</div>
				</td>
			</tr>
			@endforeach
			
		</tbody>

	</table>
</div>




</div>
@endsection