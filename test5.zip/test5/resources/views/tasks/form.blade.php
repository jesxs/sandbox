@csrf 

<div class="row">
	<div class="col-1"></div>
 		<div class="col-3">
 	@if ($errors->any())
 			<div class="alert alert-danger mt-2" role="alert">
				<strong>{{ implode('', $errors->all(':message')) }}</strong>
			</div>
	@endif
		</div>
	<div class="col"></div>
</div>

<div class="row">
 	<div class="col-1"></div>
 		<div class="col-3">
			<div class="form-group">
				<label for="taskTitle">Task title</label>
				<input type="text" class="form-control" name="task_title" value="{{old('task_title',$task->task_title)}}">
			</div>
		</div>
		<div class="col-2">
			<div class="form-group">
				<label for="Person">Person</label>
				<select name="person_id" class="form-control">
				@if (count($person) == 0)			
					<option>There are no persons.</option>
				@else
				@foreach($person as $person)
					<option value="{{$person->user_id}}">{{$person->name}}</option>
				@endforeach
				@endif
				</select>
			</div>
		</div>
</div>
<div class="row">
	<div class="col-1"></div>
		<div class="col-3">
			<div class="form-group">
				<label for="taskDesc">Description</label>
				<input type="text" class="form-control" name="task_desc" value="{{old('task_desc',$task->task_desc)}}">
			</div>
		</div>
		<div class="col-2">
			<div class="form-group">
 				<label for="status" class="text-dark">Status</label>
				<select name="status" class="form-control" value="{{old('status', $task->status)}}">
					<option value="1" selected="selected">Not started</option>
					<option value="2">In progress</option>
					<option value="3">Completed</option>
					<option value="4">Cancelled</option>
				</select>
 			</div>
		</div>
</div>
<div class="row">
	<div class="col-1"></div>
		<div class="col-2">
			<div class="form-group">
				<label for="proj_id">Project</label>
				<select name="proj_id" class="form-control">
					@if (count($project) == 0)			
					<option>There are no projects.</option>
					@else
						@foreach($project as $project)
							<option value="{{$project->proj_id}}">{{$project->proj_title}}</option>
						@endforeach
					@endif
					
				</select>
			</div>
		</div>
		<div class="col-1"></div>
		<div class="col-2">
			<div class="form-group">
 				<label for="Priority" class="text-dark">Priority</label>
				<select name="priority" class="form-control" value="{{old('priority', $task->priority)}}">
					<option value="1">Urgent</option>
					<option value="2">High</option>
					<option value="3" selected="selected">Medium</option>
					<option value="4">Low</option>
				</select>
 			</div>
		</div>
</div>
<br>
<div class="row">
	<div class="col-1"></div>
	<div class="col-2">
			<div class="form-group">
				<button type="submit" class="btn btn-success">Submit</button>
			</div>
	</div>
</div>

