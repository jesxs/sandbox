 @extends('layouts.app')

@section('content')
	<form method="POST" action="{{route('tasks.update',$task)}}">
		@method('PUT')
	@include('tasks.form')
	</form>
@endsection 