@extends('layouts.app')

@section('content')

<div class="row"> 
	<div class="col-1"></div>
	<div class="col-2">
@if (Auth::user()->role == 'admin')
			<br>
			<a class="btn btn-success" href="/tasks/create">Add Task</a>
@endif
	</div>
	<div class="col-6">
	
		<form method="GET" action="/tasks/results">
		@include('tasks.filter_form')
		</form>
	</div>

<div class="col-2">
@if(session()->has('store'))
		<div class="alert alert-success mt-2" role="alert">
			<strong>Task created</strong>
		</div>
	@elseif(session()->has('update'))
		<div class="alert alert-success mt-2" role="alert">
			<strong>Task updated</strong>
		</div>
	@elseif(session()->has('delete'))
		<div class="alert alert-success mt-2" role="alert">
			<strong>Task deleted</strong>
		</div>
	@elseif(session()->has('nofilter'))
		<div class="alert alert-danger mt-2" role="alert">
			<strong>Please provide a filter parameter</strong>
		</div>
	@endif
	</div>
</div>
<br>
<div class="row">
<br>
	<div class="col-1"></div>
	<div class="col-10">
<table class="table table-bordered table-hover">
	<thead>
		<tr>
			<th>Id</th>
			<th>Title</th>
			<th>Description</th>
			<th>Project</th>
			<th>Person</th>
			<th>Status</th>
			<th>Priority</th>
			<th>Creator</th>
			<th width="120px">Created on</th>
			@if (Auth::user()->role=='admin')
			<th>Admin</th>
			@endif
		</tr>
		
	</thead>
	<tbody class="">
		@foreach ($task as $task)
		<tr>
			<td>{{$task->task_id}}</td>
			<td>{{$task->task_title}}</td>
			<td>{{$task->task_desc}}</td>
			<td>{{$task->project->proj_title}}</td>
			<td>{{$user->find($task->person_id)->name}}</td>
			<td>{{$task->status}}</td>
			<td>{{$task->priority}}</td>
			<td>{{$task->user->name}}</td>
			<td>{{$task->created_at}}</td>
			
			<td>
				<div class="dropdown">
  					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>   
					<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
						<a class="dropdown-item" href="{{route('tasks.notes',$task->task_id)}}">Notes</a>
				
			@if (Auth::user()->role=='admin')  			 		
 				 
 	  			 		<a class="dropdown-item" href="{{route('tasks.edit',$task)}}">Edit</a>

 	  			 		<form method="POST" action="{{route('tasks.destroy',$task)}}" onsubmit="return confirm('Are you sure you want to delete this?')">
 	  			 		@method('DELETE')
 	  			 		@csrf
 			  				<button class="dropdown-item" type="submit">Delete</button>
  				  		</form>
				 	</div>
				</div>
			</td>
			@endif

		</tr>
		@endforeach
	</tbody>
</table>
</div>
<div class="col-1"></div>


</div>

@endsection