@csrf
		<div class="row">
			<div class="col">
				<div class="form-group">
					<label for="personFilter">Person</label>
					<select class="form-control" name="person">
						<option selected="selected" value="null"></option>
						@foreach ($user as $person)
							<option value="{{$person->user_id}}">{{$person->name}}</option>
						@endforeach
						
					</select>
				</div>
			</div>
			<div class="col">
				<div class="form-group">
					<label for="statusFilter">Status</label>
					<select class="form-control" name="status">
						<option selected="selected" value="null"></option>
						<option value="not-started">Not started</option>
						<option value="in-progress">In progress</option>
						<option value="completed">Completed</option>
						<option value="cancelled">Cancelled</option>
						
					</select>
				</div>
			</div>
			<div class="col">
				<div class="form-group">
					<label for="priorityFilter">Priority</label>
					<select class="form-control" name="priority">
						<option selected="selected" value="null"></option>
						<option value="urgent">Urgent</option>
						<option value="high">High</option>
						<option value="medium">Medium</option>
						<option value="low">Low</option>
						
					</select>
				</div>
			</div>
		
			
			<div class="col">
				<div class="form-group">
					<br>
					<button type="submit" class="btn btn-warning">Filter</button>
				</div>
			</div>


</div>
