@extends('layouts.app')


@section('content')
	<form method="GET" action="/tasks/results">
	@include('tasks.filter_form')
	</form>

<table class="table table-bordered table-hover">
	<thead>
		<tr>
			<th>Task Id</th>
			<th>Project</th>
			<th>Task title</th>
			<th>Description</th>
			<th>Status</th>
			<th>Priority</th>
			<th>Created by</th>
			<th>Created on</th>
			@if (Auth::user()->role=='admin')
			<th>Admin</th>
			@endif
		</tr>
		
	</thead>
	<tbody class="">
		@foreach ($task as $task)
		<tr>
			<td>{{$task->task_id}}</td>
			<td>{{$task->project->proj_title}}</td>
			<td>{{$task->task_title}}</td>
			<td>{{$task->task_desc}}</td>
			<td>{{$task->status}}</td>
			<td>{{$task->priority}}</td>
			<td>{{$task->user->name}}</td>
			<td>{{$task->created_at}}</td>
			@if (Auth::user()->role=='admin')
			<td>
				<div class="dropdown">
  					<button class="btn btn-danger dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action</button>   							   					
 				<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
 	  			 	<a class="dropdown-item" href="{{route('tasks.edit',$task)}}">Edit</a>

 	  			 	<form method="POST" action="{{route('tasks.destroy',$task)}}" onsubmit="return confirm('Are you sure you want to delete this?')">
 	  			 		@method('DELETE')
 	  			 		@csrf
 			  		<button class="dropdown-item" type="submit">Delete</button>
  				  	</form>
				 </div>
			</div>
			</td>
			@endif

		</tr>
		@endforeach
	</tbody>
</table>
@endsection