<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class Client extends Model

{
    protected $primaryKey = 'client_id';
    protected $fillable= ['client_name','client_id'];
  	public function projects (){
  		return $this->hasMany('App\Project','client_id');

  	}
    
  	protected static function boot() {
        parent::boot();
        static::deleting(function(Client $client) {
             $client->projects()->delete();
        });
    }
}
  