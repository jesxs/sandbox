<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Note extends Model
{
	protected $fillable = ['note','created_by','task_id'];


    public function task(){

    	return $this->belongsTo('App\Task','task_id');
    }
    public function user(){

    	return $this->belongsTo('App\User','created_by');
    }
}
