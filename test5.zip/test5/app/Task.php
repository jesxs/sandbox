<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    protected $primaryKey = 'task_id';

    protected $fillable = ['task_title','task_desc','status','priority','person_id','proj_title','proj_id','created_by'];

    public function project(){

    	return $this->belongsTo('App\Project','proj_id');
    }
    public function user(){

    	return $this->belongsTo('App\User','created_by');
    }
    public function notes(){

    	return $this->hasMany('App\Note','task_id');
    }
     

}
