<?php

namespace App\Http\Controllers;

use App\Task;
use Auth;
use App\Project;
use App\Client;
use App\User;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    
    public function index()
    {
        return view('tasks.index', [
            'task' => Task::all(),
            'project' => Project::all(),
            'user' => User::all(),
        ]);
    }
    public function index_api()
    {
        return response()->json(Task::all());
    }
    public function filter(Request $r){
        
        $person = $r['person'];
        $status = $r['status'];
        $priority = $r['priority'];
        $filterMode = '';


        if (($person  === 'null')&&($status === 'null')&&($priority === 'null')){

            return redirect('/tasks')->with('nofilter','');

        }else{
 
            if ($person != 'null'){
                $filterMode = "person";
                echo "<script>console.log('reached 1')</script>";

            }elseif($status != 'null'){
                $filterMode = "status";
                echo "<script>console.log('reached 2')</script>";

            }elseif($priority != 'null'){
                $filterMode = "priority";
                echo "<script>console.log('reached 2')</script>";
            }
            switch ($filterMode) {
                case 'person':
                        $result = Task::all()->where('person_id',$person);
                        return view('tasks/index', [
                            'task' => $result,
                            'client' => Client::all(),
                            'user' => User::all(),
                        ]);
                    break;
                case 'status':
                        $result = Task::all()->where('status',$status);
                        return view('tasks/index', [
                            'task' => $result,
                            'client' => Client::all(),
                            'user' => User::all(),

                        ]);
                    break;
                case 'priority':
                        $result = Task::all()->where('priority',$priority);
                        return view('tasks/index', [
                            'task' => $result,
                            'client' => Client::all(),
                            'user' => User::all(),
                        ]);
                    break;
            }
        }
        
            
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (Auth::user()->role != 'admin'){
            return redirect()->back();
        }else{

        return view('tasks.create',[
            'task' => new Task,
            'project' => Project::all(),
            'person' => User::all()
        
            ]);
        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $r)
    {
        $validatedData = $r->validate([
            'task_title' => 'required|max:100',
            'task_desc' => 'required',
        ]);
        $currentUserId = Auth::user()->user_id;
        $r['created_by'] = $currentUserId;
        $task = Task::create($r->all());
        return redirect('/tasks')->with('store','');
    }

    public function store_api(Request $data){
        $data->validate([
            'task_title'=>'required',
            'proj_id'=>'required',
            'task_desc'=>'required',
            'status'=>'required',
            'priority'=>'required',
            'created_by'=>'required',
        ]);
        $task = new Task([
            'proj_id'=> $data->proj_id,
            'task_title'=>$data->task_title,
            'task_desc'=>$data->task_desc,
            'status'=>$data->status,
            'priority'=>$data->priority,
            'created_by'=>$data->created_by,
        ]);

        $task->save();
        return response()->json(['message'=>'Task created']);


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Task  $task
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $task = Task::findOrFail($id);
        return response()->json($task);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Task  $task
     * @return \Illuminate\Http\Response
     */
    public function edit(Task $task)
    {
         if (Auth::user()->role != 'admin'){
            return redirect()->back();
        }else{
        return view('tasks.edit', [
            'task' => $task,
            'project' => Project::all(),
            'person' => User::all()
            ]);
    }
    }
    public function edit_api(Request $r,$id){
        $task = Task::findOrFail($id);
        $task->update($r->all());
        return response()->json(['message' => 'task with id '.$task->task_id.' updated succesfully.']);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Task  $task
     * @return \Illuminate\Http\Response
     */
    public function update(Request $r, Task $task)
    {
        $task->update($r->all());
        return redirect('/tasks')->with('update','');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Task  $task
     * @return \Illuminate\Http\Response
     */
    public function destroy(Task $task)
    {
        $task->delete();
        return redirect('/tasks')->with('delete','');
    }
    public function destroy_api($id)
    {
        $task = Task::findOrFail($id);
        $task->delete();
        return response()->json(['message'=>'Task with id '.$id.' deleted.']);
    }
}
