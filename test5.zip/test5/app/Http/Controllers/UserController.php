<?php

namespace App\Http\Controllers;

use App\User;
use Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;


class UserController extends Controller
{ 
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response


     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    
    public function index()
    {
        return view('users.index', [
            'user' => User::all()
        ]);
    }
    public function index_api(){
        return response()->json(User::all());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (Auth::user()->role != 'admin'){
            return redirect()->back();
        }else{

        return view('users.create',[
            'user' => new User,
        
        ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $r)
    {
        $validatedData = $r->validate([
            'name' => 'required|max:25',
            'password' => 'required',
            'role' => 'required'
        ]);
        
        $password = $r['password'];
        $hashedPassword = bcrypt($password);

        $r['password'] = $hashedPassword;

        $user = User::create($r->all());
        return redirect('/users')->with('store','');
        
    }
    public function store_api(Request $data){
        $data->validate([
            'name' => 'required',
            'password' => 'required',
            'role' => 'required',

        ]);
        $password = $data->password;
        $hashedPassword = bcrypt($password);

        $user = new User([
            'name' => $data->name,
            'password' => $hashedPassword,
            'role' => $data->role,

        ]);
        $user->save();
        return response()->json(['message'=>'New user succesfully created.']);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\User  $User
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return response()->json(User::findOrFail($id));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\User  $User
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        return view('users.edit', compact('user'));
    }
    public function edit_api(Request $r, $id){
        $user = User::findOrFail($id);
        $user->update($r->all());
        return response()->json(['User with id '.$id.' succesfully updated.']);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\User  $User
     * @return \Illuminate\Http\Response
     */
    public function update(Request $r, User $user)
    {
        $password = $r['password'];
        $hashedPassword = bcrypt($password);

        $r['password'] = $hashedPassword;

        $user->update($r->all());
        return redirect('/users')->with('update','');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\User  $User
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $User)
    {
        $User->delete();
        return redirect('/users')->with('delete','');
    }
    public function destroy_api($id){
        $user = User::findOrFail($id);
        $user->delete();
        return response()->json(['User deleted.']); 
    }
}
