<?php

namespace App\Http\Controllers;

use App\Client;
use Auth;
use Illuminate\Http\Request;

class ClientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    
    public function index()
    {
        return view('clients.index',[
            'client' => Client::all()
        ]);
    }
    public function index_api(){
        return response()->json(Client::all());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth::user()->role != 'admin'){
            return redirect()->back();
        }else{

         return view('clients.create',[
            'client' => new Client,
        ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $r)
    {
        $validatedData = $r->validate([
            'client_name' => 'required|max:100',
        ]);

        $client = Client::create($r->all());
        return redirect('/clients')->with('store','');
    }
    public function store_api(Request $data){
        $data->validate([
            'client_name' => 'required',
        ]);
        $client = Client::create($data->all());
        return response()->json(['message'=>'Client created succesfully']);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Client  $client
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $client = Client::findOrFail($id);
        return response()->json($client);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Client  $client
     * @return \Illuminate\Http\Response
     */
    public function edit(Client $client)
    {

         if (Auth::user()->role != 'admin'){
            return redirect()->back();
        }else{
        return view('clients.edit', compact('client'));
    }
    }
    public function edit_api(Request $r,$id){
        $client = Client::findOrFail($id);
        $client->update($r->all());
        return response()->json(['message'=>'Client with id '.$id.' updated.']);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Client  $client
     * @return \Illuminate\Http\Response
     */
    public function update(Request $r, Client $client)
    {
        $client->update($r->all());
        return redirect('/clients')->with('update','');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Client  $client
     * @return \Illuminate\Http\Response
     */
    public function destroy(Client $client)
    {
        $client->delete();
        return redirect('/clients')->with('delete','');
    }
    public function destroy_api($id)
    {
        $client = Client::findOrFail($id);
        $client->delete();
        return response()->json(['message'=>'Client deleted.']);
    }
}
