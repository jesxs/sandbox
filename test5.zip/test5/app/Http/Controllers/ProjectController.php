<?php 

namespace App\Http\Controllers;

use App\Project;
use App\Client;
use App\User;
use App\Task;
use Auth;
use Illuminate\Http\Request;
use App\Http\Resources\Project as ProjectResource;

class ProjectController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
        
    }



    public function index()
    {
        
        return view('projects.index', [
            'projects' => Project::all(),
            'client' => Client::all(),
            'user'=> User::all(),
        ]);
        

    }
    public function index_api()
    {
        
        return response()->json(Project::all());
        

    }
    public function filter(Request $r){
        
        $client = $r['client'];
        $created_by = $r['created_by'];
        $filterMode = '';


        if (($client  === 'null')&&($created_by === 'null')){

            return redirect('/projects')->with('nofilter','');

        }else{
 
            if ($client != 'null'){
                $filterMode = "client";
                        echo "<script>console.log('reached 1')</script>";


            }elseif($created_by != 'null'){
                $filterMode = "creator";
                echo "<script>console.log('reached 2')</script>";

            }

            switch ($filterMode) {
                case 'client':
                        $result = Project::all()->where('client_id',$client);
                        return view('projects/index', [
                            'projects' => $result,
                            'client' => Client::all(),
                            'user' => User::all(),
                        ]);
                    break;
                case 'creator':
                        $result = Project::all()->where('created_by',$created_by);
                        return view('projects/index', [
                            'projects' => $result,
                            'client' => Client::all(),
                            'user' => User::all(),
                        ]);
                    break;
            }
        }
    }


public function seeTasks($project){
    $result = Task::all()->where('proj_id', $project);
    if($result->isEmpty()){
        return redirect('/projects')->with('noTask','');
    }else{
    return view('projects.tasks',[
        'result' => $result,
        'user' => User::all(),
    ]);
    }
}
public function seeTasks_api($id){
    $result = Task::all()->where('proj_id', $id);
    if($result->isEmpty()){
        return response()->json(['message' => 'That project has no tasks.']);
    }else{
    return response()->json($result);
    }
}
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {


        if (Auth::user()->role != 'admin'){
            return redirect()->back();
        }else{

        return view('projects.create',[
            'project' => new Project,
            'clients' => Client::all(),

        ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $r)
    {

        $validatedData = $r->validate([
            'proj_title' => 'required|max:100',
            'client_id' => 'required',
            'proj_desc' => 'required',
        ]);



        $r['created_by'] = Auth::user()->user_id;



        $project = Project::create($r->all());
        return redirect('/projects')->with('store','');
    }

    public function store_api(Request $data){


      

        $data->validate([
            'proj_title' => 'required|string',
            'proj_desc' => 'required|string',
            'client_id' => 'required|integer',
            'created_by' => 'required'

        ]);

        $project = new Project([
            'proj_title'     => $data->proj_title,
            'proj_desc'    => $data->proj_desc,
            'client_id' => $data->client_id,
            'created_by' => $data->created_by
        ]);
        $project ->save();
        

        //$project = Project::create($data->all());
       
        return response()->json(['message'=>'New project created']);
        
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $project = Project::findOrFail($id);
        return response()->json($project);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function edit(Project $project)
    {
         if (Auth::user()->role != 'admin'){
            return redirect()->back();
        }else{


        return view('projects.edit',[
            compact('project'),
            'project' => Project::find($project->proj_id),
            'clients' => Client::all(),
            ]);
    }

    }
    public function edit_api(Request $r,$id){

        $project = Project::findOrFail($id);
        $project->update($r->all());
        return response()->json(['message' =>'Project with id '.$project->proj_id.' was succesfully updated.']);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function update(Request $r, Project $project)
    {
        $project->update($r->all());
        return redirect('/projects')->with('update','');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function destroy(Project $project)
    {
        $project->delete();
        return redirect('/projects')->with('delete','');
    }
    public function destroy_api($id)
    {
        $project = Project::findOrFail($id);
        $project->delete();
        return response()->json(['message'=>'Project with id '.$id.' deleted succesfully']);
        
    }
}
