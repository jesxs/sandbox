<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Project extends Model
{
    protected $primaryKey = 'proj_id';
    protected $fillable = ['proj_title','proj_desc','client_id','created_by'];

    
    
    public function client (){
    	return $this->belongsTo('App\Client');
    }
    public function tasks (){
    	return $this->hasMany('App\Task','proj_id');
    }
    public function user (){
    	return $this->belongsTo('\App\User','created_by');
    }




    protected static function boot() {

        parent::boot();

        static::deleting(function(Project $project) {

             $project->tasks()->delete();
             
        });
        
    }
    




}
