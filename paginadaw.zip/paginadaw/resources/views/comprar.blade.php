@extends('layout')


@section('content')

	<h1 id="noCompres">NO COMPRES, ADOPTA</h1>

@endsection