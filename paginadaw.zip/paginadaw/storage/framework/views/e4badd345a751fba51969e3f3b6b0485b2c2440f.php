<?php $__env->startSection('content'); ?>

	<h1 id="noCompres">NO COMPRES, ADOPTA</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Programas\xampp\htdocs\paginadaw\resources\views/comprar.blade.php ENDPATH**/ ?>