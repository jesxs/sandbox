<?php $__env->startSection('content'); ?>

<div class="tiposHolder">
	<div class="gatoTipoHolder">
		<div class="gatoTipoFotoHolder"><img src="img/gatoPersa.jpg"></div>
		<div class="gatoTipoTextoHolder">
			<div class="tipoGatoNombreHolder"><span>❤️Persa</span></div>	
			<div class="leerMasHolder"></div>
			<hr>
			<p>
				El Persa es una raza de gato caracterizada por tener una cara ancha y plana y un gran abundante pelaje de variados colores. Son considerados comúnmente como gatos aristocráticos (el 75% de los gatos de pedigree registrados son persas). Los primeros gatos persas fueron introducidos en Italia desde Persia (actual Irán) en la década de 1620 y a sus descendientes se les llamó de muchas maneras.
			</p>
		</div>

		

	</div>
	<div class="gatoTipoHolder">
		<div class="gatoTipoFotoHolder"><img src="img/gatoBengala.jpg"></div>
		<div class="gatoTipoTextoHolder">
			<div class="tipoGatoNombreHolder"><span>❤️Bengala</span></div>
			<div class="leerMasHolder"></div>
			<hr>
			<p>
				El bengala es una raza de gato doméstica desarrollada para parecerse a los felinos salvajes exóticos tales como son los leopardos, ocelotes, margays, etc. El gato bengala, fue un resultado fortuito del cruce casual entre un gato doméstico y una hembra gato leopardo
			</p>
		</div>
	</div>
	<div class="gatoTipoHolder">
		<div class="gatoTipoFotoHolder"><img src="img/gatoMaine.jpg"></div>
		<div class="gatoTipoTextoHolder">
			<div class="tipoGatoNombreHolder"><span>❤️Maine Coon</span></div>
			<hr>

			<p>A pesar de las muchas leyendas que sitúan el origen del Maine Coon a partir de los angoras turcos que vivían en Europa, debemos afirmar que son muchas las diferencias entre estas dos razas; empezando por el tamaño. El Maine Coon es una de las razas de felinos domésticos más grandes y de mayor peso.</p>
		</div>
	</div>
	<div class="gatoTipoHolder">
		<div class="gatoTipoFotoHolder"><img src="img/gatoSiames.jpg"></div>
		<div class="gatoTipoTextoHolder">
			<div class="tipoGatoNombreHolder"><span>❤️Siam&eacute;s</span></div>
			<hr>

			<p>El siamés moderno es una raza de gato proveniente del antiguo reino de Siam, actualmente Tailandia. En 1882 fueron llevados a Inglaterra y en 1890 a Estados Unidos.

			Este tipo de siamés, desde 1950, fue ganando protagonismo y resultó ser el elegido por los criadores y jueces de exposiciones felinas. Tal vez sea por esto que se acuñó el nombre "siamés" para el siamés moderno, ya que es la variedad que durante todas estas décadas ha participado a nivel de competición.</p>
		</div>
	</div>
	<div class="gatoTipoHolder">
		<div class="gatoTipoFotoHolder"><img src="img/sphynx.jpg"></div>
		<div class="gatoTipoTextoHolder">
			<div class="tipoGatoNombreHolder"><span>❤️Sphynx</span></div>
			<hr>

			<p>El Sphynx o gato esfinge es una raza de gato cuya característica más llamativa es la aparente ausencia de pelaje y su aspecto delgado y esbelto. Aunque los ejemplares de la raza parecen ser gatos sin pelos, hay que destacar que verdaderamente no son gatos pelados, sino que presentan la piel cubierta de una capa de vello muy fino, corto y parejo, casi imperceptible a la vista o al tacto.</p>
		</div>
	</div>
	<div class="gatoTipoHolder">
		<div class="gatoTipoFotoHolder"><img src="img/britishShorthair.jpg"></div>
		<div class="gatoTipoTextoHolder">
			<div class="tipoGatoNombreHolder"><span>❤️British Shorthair</span></div>
			<hr>

			<p>Los británicos de pelo corto, probablemente la raza de gato Inglesa más antigua, tiene sus antepasados hasta los gatos domésticos de Roma. Esta raza era muy apreciada primero por su fortaleza física y su habilidad para cazar, pero pronto se convirtió igualmente reconocida y valorada por su comportamiento tranquilo, de resistencia y la lealtad al hombre.</p>
		</div>
	</div>
	<div class="gatoTipoHolder">
		<div class="gatoTipoFotoHolder"><img src="img/munchkin.jpg"></div>
		<div class="gatoTipoTextoHolder">
			<div class="tipoGatoNombreHolder"><span>❤️Munchkin</span></div>
			<hr>

			<p>El Munchkin es una raza de gato surgida por una mutación genética natural, mantenida por cruzamientos selectivos, que da lugar a gatos con piernas más cortas de lo normal. Sin embargo, la poca longitud de sus piernas no parece interferir con sus habilidades a la hora de correr y saltar. Los Munchkins no sufren de los muchos problemas de la columna vertebral que se asocian típicamente con las razas caninas porque las columnas vertebrales de los gatos son diferentes de las de los perros.</p>
		</div>
	</div>
	<div class="gatoTipoHolder">
		<div class="gatoTipoFotoHolder"><img src="img/savanah.jpg"></div>
		<div class="gatoTipoTextoHolder">
			<div class="tipoGatoNombreHolder"><span>❤️Savannah</span></div>
			<hr>

			<p>El gato savannah es la raza de gato domesticada más grande. Un gato savannah es un cruce entre un gato doméstico y un serval, un gato africano salvaje de tamaño mediano y orejas grandes. El cruce inusual se hizo popular entre los criadores a fines de la década de 1990, y en 2001 The International Cat Association (TICA) la aceptó como una nueva raza registrada. En mayo de 2012, TICA lo aceptó como una raza de campeonato.</p>
		</div>
	</div>
	<div class="gatoTipoHolder">
		<div class="gatoTipoFotoHolder"><img src="img/gatoComun.jpg"></div>
		<div class="gatoTipoTextoHolder">
			<div class="tipoGatoNombreHolder"><span>❤️Com&uacute;n europeo</span></div>
			<hr>

			<p>El gato común europeo es una raza de gato, como su nombre indica, originario de Europa, probablemente descendiente del gato montés africano y del gato de la jungla. Fue reconocido como raza el 1 de enero de 1983. Los felinos de esta raza son fuertes y cuentan con un sólido sistema inmunológico.</p>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Programas\xampp\htdocs\paginadaw\resources\views/tipos.blade.php ENDPATH**/ ?>