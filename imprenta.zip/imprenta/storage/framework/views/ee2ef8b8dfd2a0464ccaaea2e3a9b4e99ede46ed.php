<br><br><br>

	<div class="row">
		<br>
		<div class="mx-auto">
			<div class="background-3 animated fadeInDown">
				<div class="col">
					<div class="animated bounceInLeft">
						<span class="emojis">&#9993;</span><span class="contact-text"> imprentasanchezhellin@yahoo.es</span><br>
					</div>
					<div class="col">
					<div class="animated bounceInLeft" style="animation-delay: 0.5s;">
						<span class="emojis">&#128222;</span><span class="contact-text"> 967 30 09 10 / 618 83 18 17</span>
					</div>
				</div>
				</div>
			</div>
		</div>
<?php /**PATH D:\Programas\xampp\htdocs\imprenta\resources\views/menu/contacto.blade.php ENDPATH**/ ?>