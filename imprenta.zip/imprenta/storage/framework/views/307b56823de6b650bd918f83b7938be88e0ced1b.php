<br><br><br>

<div class="background-2">
	<div class="row">
		<div class="col-4">
			<div class="custom-card animated zoomIn">
			  <img src="https://i.ibb.co/G76KXBM/Best-Personal-Finance-Books.jpg" class="card-img-top" alt="...">
			  
			</div>
		</div>
		<div class="col-4">
			<div class="custom-card animated zoomIn">
			  <img src="https://i.ibb.co/FztVyth/images.jpg" class="card-img-top" alt="...">
			  
			</div>
		</div>
		<div class="col-4">
			<div class="custom-card animated zoomIn">
			  <img src="https://i.ibb.co/47nSVtG/descarga.jpg" class="card-img-top" alt="...">
			</div>
		</div>
	</div>
	<br>
	<div class="row">
		<div class="col-4">
			<div class="custom-card animated zoomIn">
			  <img src="https://i.ibb.co/SdtDQxm/tarjeta-visita-imprenta-irun.jpg" class="card-img-top" alt="...">
			  
			</div>
		</div>
		<div class="col-4">
			<div class="custom-card animated zoomIn">
			  <img src="https://i.ibb.co/gW7R8Q2/tarjetas-de-presentacion.jpg" class="card-img-top" alt="...">
			  
			</div>
		</div>
		<div class="col-4">
			<div class="custom-card animated zoomIn">
			  <img src="https://i.ibb.co/6g1CN1b/vinilos-personalizados.jpg" class="card-img-top" alt="...">
			</div>
		</div>
	</div>
</div>

<br><br><br><?php /**PATH D:\Programas\xampp\htdocs\imprenta\resources\views/menu/trabajos.blade.php ENDPATH**/ ?>