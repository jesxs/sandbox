

<br><br><br>
                <div class="row">
                    <br>
                    <div class="holder mx-auto animated bounceInUp">
                        <div class="col-12" style="">
                            <div id="button1" class="square-box">
                                <img id="icon-1" class="icon" src="https://i.ibb.co/hDZ6SBF/image-icon.png" width="65px" height="50px"><br><br>
                                <span id="square-text-1" class="square-text">Trabajos</span>
                            </div>

                            <div id="button2" class="square-box">
                                <img class="icon" src="https://i.ibb.co/25105xy/5a4525b2546ddca7e1fcbc82.png" alt="5a4525b2546ddca7e1fcbc82" width="55px" height="50px"><br><br>
                                <span class="square-text">Contacto</span>
                            </div>
                    
                            <div id="button3" class="square-box">
                                <img class="icon" src="https://i.ibb.co/sj5cBdh/img-466165.png" width="65px" height="50px"><br><br>
                                <span class="square-text">Empresa</span>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>




<?php /**PATH D:\Programas\xampp\htdocs\imprenta\resources\views/main.blade.php ENDPATH**/ ?>