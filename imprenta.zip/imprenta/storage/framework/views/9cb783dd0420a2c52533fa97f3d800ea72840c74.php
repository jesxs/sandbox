<?php $__env->startSection('content'); ?>
<h1>hola jaja</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imprenta-laravel\imprenta\resources\views/works.blade.php ENDPATH**/ ?>