

$(document).ready(function(){
	$.ajaxSetup({
  		cache: false
	});

	$(document).on('click', '#button1', function() {
    	$.ajax({url:'/trabajos',success:function(result) {
        $("#app").html(result).hide().fadeIn(1200);
    	}});
	});
	$(document).on('click', '#button2', function() {
    	$.ajax({url:'/contacto',success:function(result) {
        $("#app").html(result).hide().fadeIn(1200);
    	}});
	});
	$(document).on('click', '#button3', function() {
    	$.ajax({url:'/empresa',success:function(result) {
        $("#app").html(result).fadeIn('slow');
    	}});
	});
	$(document).on('click', '#home-button', function() {
    	$.ajax({url:'/main',success:function(result) {
        $("#app").html(result).fadeIn('slow');
    	}});
	});







});




