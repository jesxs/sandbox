@extends('welcome')

@section('content')
<section class="contact">
	<div class="contact-text">
		<h1 class="contact-title">Contacto</h1>
		<p class="contact-paragraph">Para cualquier duda o consulta no dudes en contactarnos:</p>
	</div>

	<div class="contact-items">
		<div class="contact-item">
			<img class="phone-icon" src="./images/contact-telf.png">
			<h3>967 30 09 10</h3>
		</div>
		<div class="contact-item">
			<img class="maps-icon" src="./images/contact-maps.png">
			<h3>C/ Francos Rodriguez, Nº4</h3>
		</div>
		<div class="contact-item">
			<img class="email-icon" src="./images/contact-email.png">
			<h3>imprentasanchezhellin@yahoo.es</h3>
		</div>

	</div>
</section>




<img class="big-circle" src="./images/big-eclipse.svg">
<img class="med-circle" src="./images/mid-eclipse.svg">
<img class="small-circle" src="./images/small-eclipse.svg">
@endsection