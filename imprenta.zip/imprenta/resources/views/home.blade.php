@extends('welcome')

@section('content')
<section class="presentation">
                <div class="introduction">
                    <div class="intro-text animated fadeIn">
                        <h1>Imprenta Sánchez</h1>
                        <p>
                            Imprimimos tus ideas desde 1956
                        </p>
                    </div>
                    <div class="cta animated fadeIn">
                        <button class="cta-select">Leer más</button>
                        <button class="cta-contact" href="/contacto">Contactar</button>
                    </div>
                </div>
                <div class="cover animated fadeIn">
                    <img src="./images/imprenta-fachada.jpg">
                </div>
</section>
<img class="big-circle" src="./images/big-eclipse.svg">
<img class="med-circle" src="./images/mid-eclipse.svg">
<img class="small-circle" src="./images/small-eclipse.svg">
@endsection