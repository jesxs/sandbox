@extends('welcome')

@section('content')
<section class="products">
	<div class="item-left animated slideInUp">
		<img class="image-left" src="./images/flyer.png">
		<div class="product-desc">
			<h1>Flyers</h1>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec auctor odio massa, vel luctus orci efficitur ut. Pellentesque efficitur efficitur lorem nec varius.</p>
		</div>
	</div>
	<div class="item-right animated slideInUp">
		<div class="product-desc-right" style="margin-right: 6vh;">
			<h1>Tarjetas de boda</h1>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec auctor odio massa, vel luctus orci efficitur ut. Pellentesque efficitur efficitur lorem nec varius.</p>
		</div>
		<img class="image-right" src="./images/tarjetas-boda.jpg">
	</div>
	<div class="item-left animated slideInUp">
		<img class="image-left" src="./images/lonas.jpg">
		<div class="product-desc">
			<h1>Lonas publicitarias</h1>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec auctor odio massa, vel luctus orci efficitur ut. Pellentesque efficitur efficitur lorem nec varius.</p>
		</div>
	</div>

</section>
<br><br>
<img class="big-circle" src="./images/big-eclipse.svg">
<img class="med-circle" src="./images/mid-eclipse.svg">
<img class="small-circle" src="./images/small-eclipse.svg">


@endsection