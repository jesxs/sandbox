<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="./css/style.css">
        <link rel="stylesheet" type="text/css" href="./css/animate.css">
        <title>Imprenta Sanchez</title>
    </head>
    <body>
        <header>
            <div class="logo-container">
                <a href="/"><img class="logo" src="./images/IMPRENTA-0.png"></a>
            </div>
            <nav>
                <ul class="nav-links">
                    <li><a class="nav-link" href="/trabajos">Trabajos</a></li>
                    <li><a class="nav-link" href="/productos">Productos</a></li>
                    <li><a class="nav-link" href="/contacto">Contacto</a></li>
                </ul>
            </nav>
        </header>

        <main>
            @yield('content')
        </main>
        <footer>
            
        </footer>
    </body>
</html>