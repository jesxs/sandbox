@extends('home')

@section('content')
<h1>hola jaja</h1>

@endsection