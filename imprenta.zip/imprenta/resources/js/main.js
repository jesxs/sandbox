$('#1').click(function(){


alert("sdsda");
})